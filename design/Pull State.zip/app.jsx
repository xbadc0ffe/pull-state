// app.jsx — Pull State main app, navigation, theme + tweaks wiring

const { useState, useEffect, useMemo } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "dark": true,
  "showOnboarding": false
}/*EDITMODE-END*/;

function PullStateApp() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    document.body.classList.toggle('light', !tweaks.dark);
  }, [tweaks.dark]);

  const theme = tweaks.dark ? PS_THEME.dark : PS_THEME.light;

  const [seenOnboarding, setSeenOnboarding] = useState(() => {
    try { return localStorage.getItem('ps_onb') === '1'; } catch { return false; }
  });
  const showOnboarding = tweaks.showOnboarding || !seenOnboarding;

  const finishOnboarding = () => {
    try { localStorage.setItem('ps_onb', '1'); } catch {}
    setSeenOnboarding(true);
    if (tweaks.showOnboarding) setTweak('showOnboarding', false);
  };
  const replayOnboarding = () => {
    try { localStorage.removeItem('ps_onb'); } catch {}
    setSeenOnboarding(false);
    setTweak('showOnboarding', true);
  };

  // Data
  const [machines, setMachines] = useState(PS_SEED_MACHINES);
  const [grinders, setGrinders] = useState(PS_SEED_GRINDERS);
  const [beans, setBeans] = useState(PS_SEED_BEANS);
  const [shots, setShots] = useState(PS_SEED_SHOTS);

  // Routing
  const [tab, setTab] = useState('log');
  const [stack, setStack] = useState([]);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [addBeanOpen, setAddBeanOpen] = useState(false);
  const [addHardwareKind, setAddHardwareKind] = useState(null);

  const push = (r) => setStack(s => [...s, r]);
  const pop = () => setStack(s => s.slice(0, -1));
  const top = stack[stack.length - 1];
  const switchTab = (t) => { setTab(t); setStack([]); };

  const onSaveShot = (s) => {
    const id = 's' + (shots.length + 1);
    setShots([{ id, ...s }, ...shots]);
    setTab('history');
  };

  const nextBagNumber = (beans[0]?.bagNumber || 0) + 1;
  const onSaveBean = (b) => {
    const id = 'b' + (beans.length + 1);
    setBeans([{ id, bagNumber: nextBagNumber, ratings: [], ...b }, ...beans]);
    setAddBeanOpen(false);
  };
  const onUpdateRecipe = (beanId, recipe) => {
    setBeans(beans.map(b => b.id === beanId ? { ...b, recipe } : b));
  };

  const onSaveHardware = (item) => {
    if (addHardwareKind === 'machine') {
      const id = 'm' + (machines.length + 1);
      setMachines([{ id, shotCount: 0, ...item }, ...machines]);
    } else if (addHardwareKind === 'grinder') {
      const id = 'g' + (grinders.length + 1);
      setGrinders([{ id, shotCount: 0, ...item }, ...grinders]);
    }
    setAddHardwareKind(null);
  };

  const tabs = [
    { id: 'log',      label: 'LOG',      icon: PS_ICONS.log },
    { id: 'history',  label: 'HISTORY',  icon: PS_ICONS.history },
    { id: 'beans',    label: 'BEANS',    icon: PS_ICONS.beans },
    { id: 'hardware', label: 'HARDWARE', icon: PS_ICONS.hardware },
  ];

  let screen;
  if (top?.kind === 'shot') {
    const shot = shots.find(s => s.id === top.id);
    const bean = beans.find(b => b.id === shot?.beanId);
    const machine = machines.find(m => m.id === shot?.machineId);
    const grinder = grinders.find(g => g.id === shot?.grinderId);
    screen = <PSShotDetail theme={theme} shot={shot} bean={bean} machine={machine} grinder={grinder} onBack={pop} />;
  } else if (top?.kind === 'bean') {
    const bean = beans.find(b => b.id === top.id);
    screen = <PSBeanDetail theme={theme} bean={bean} shots={shots} onBack={pop} onUpdateRecipe={onUpdateRecipe} />;
  } else if (tab === 'log') {
    screen = <PSLogScreen theme={theme} machines={machines} grinders={grinders} beans={beans}
      defaults={{ machineId: machines[0].id, grinderId: grinders[0].id, beanId: beans[0].id }}
      onSave={onSaveShot} onShowAbout={() => setAboutOpen(true)} />;
  } else if (tab === 'history') {
    screen = <PSHistoryScreen theme={theme} shots={shots} beans={beans} machines={machines} grinders={grinders}
      onOpenShot={(id) => push({ kind: 'shot', id })} onShowAbout={() => setAboutOpen(true)} />;
  } else if (tab === 'beans') {
    screen = <PSBeansScreen theme={theme} beans={beans}
      onOpen={(id) => push({ kind: 'bean', id })}
      onAdd={() => setAddBeanOpen(true)}
      onShowAbout={() => setAboutOpen(true)} />;
  } else if (tab === 'hardware') {
    screen = <PSHardwareScreen theme={theme} machines={machines} grinders={grinders}
      onAdd={(kind) => setAddHardwareKind(kind)}
      onShowAbout={() => setAboutOpen(true)} />;
  }

  return (
    <>
      <IOSDevice dark={tweaks.dark} width={402} height={874}>
        <div style={{
          position: 'relative', width: '100%', height: '100%',
          background: theme.page,
          display: 'flex', flexDirection: 'column',
          overflow: 'hidden',
        }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0, paddingTop: 56 }}>
            {screen}
          </div>
          {!top && <PSTabBar active={tab} onChange={switchTab} theme={theme} tabs={tabs} />}

          <PSAboutSheet theme={theme} open={aboutOpen} onClose={() => setAboutOpen(false)}
            dark={tweaks.dark} onToggleDark={(v) => setTweak('dark', v)} />

          {addBeanOpen && (
            <div style={{
              position: 'absolute', inset: 0, zIndex: 60, background: theme.page, paddingTop: 56,
              animation: 'ps-fade 0.2s ease',
            }}>
              <PSBeanAddForm theme={theme} nextBagNumber={nextBagNumber}
                onCancel={() => setAddBeanOpen(false)} onSave={onSaveBean} />
            </div>
          )}

          {addHardwareKind && (
            <div style={{
              position: 'absolute', inset: 0, zIndex: 60, background: theme.page, paddingTop: 56,
              animation: 'ps-fade 0.2s ease',
            }}>
              <PSHardwareAddForm theme={theme} kind={addHardwareKind}
                onCancel={() => setAddHardwareKind(null)} onSave={onSaveHardware} />
            </div>
          )}

          {showOnboarding && (
            <div style={{ position: 'absolute', inset: 0, paddingTop: 56 }}>
              <PSOnboarding theme={theme} onFinish={finishOnboarding} onSkip={finishOnboarding} />
            </div>
          )}
        </div>
      </IOSDevice>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.dark ? 'Dark' : 'Light'}
          options={['Light', 'Dark']}
          onChange={(v) => setTweak('dark', v === 'Dark')} />
        <TweakSection label="Onboarding" />
        <TweakToggle label="Show onboarding overlay" value={tweaks.showOnboarding}
          onChange={(v) => setTweak('showOnboarding', v)} />
        <TweakButton label="Replay first-run setup" onClick={replayOnboarding} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<PullStateApp />);
