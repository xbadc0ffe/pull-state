// data.jsx — seed data for the prototype

const PS_SEED_MACHINES = [
  { id: 'm1', name: 'Linea Mini', brand: 'La Marzocco', shotCount: 142, photo: 'machine-linea' },
  { id: 'm2', name: 'Bambino Plus', brand: 'Breville', shotCount: 38, photo: 'machine-bambino' },
];
const PS_SEED_GRINDERS = [
  { id: 'g1', name: 'Niche Zero', brand: 'Niche', shotCount: 168, photo: 'grinder-niche' },
  { id: 'g2', name: 'DF64', brand: 'Turin', shotCount: 22, photo: 'grinder-df64' },
];
const PS_SEED_BEANS = [
  {
    id: 'b1', name: 'Black Gold', bagNumber: 12, roaster: 'Onyx Coffee Lab',
    singleOrigin: false, process: 'Washed', roast: 'Medium',
    roastDate: '2026-04-18', purchaseDate: '2026-04-22',
    notes: 'House blend, plays nice with milk. Espresso-forward.',
    recipe: { grind: '22', temp: 93, preInfTime: 7, preInfPressure: 3, pullTime: 28, pullPressure: 9 },
    ratings: [
      { d: '04-22', r: 3 }, { d: '04-23', r: 4 }, { d: '04-24', r: 4 },
      { d: '04-25', r: 5 }, { d: '04-26', r: 4 },
    ],
  },
  {
    id: 'b2', name: 'Geisha Esmeralda', bagNumber: 11, roaster: 'Sey Coffee',
    singleOrigin: true, process: 'Washed', roast: 'Light',
    roastDate: '2026-04-12', purchaseDate: '2026-04-15',
    notes: 'Jasmine, bergamot, white peach. Treat as filter, but extracts gorgeously as espresso when dialed.',
    recipe: { grind: '18', temp: 91, preInfTime: 9, preInfPressure: 3, pullTime: 32, pullPressure: 9 },
    ratings: [
      { d: '04-15', r: 2 }, { d: '04-17', r: 3 },
      { d: '04-19', r: 4 }, { d: '04-21', r: 5 }, { d: '04-25', r: 5 },
    ],
  },
  {
    id: 'b3', name: 'Cerro Azul', bagNumber: 10, roaster: 'Heart Roasters',
    singleOrigin: true, process: 'Natural', roast: 'Medium',
    roastDate: '2026-04-05', purchaseDate: '2026-04-09',
    notes: 'Strawberry, cocoa nib, port wine.',
    recipe: { grind: '20', temp: 92, preInfTime: 6, preInfPressure: 3, pullTime: 27, pullPressure: 9 },
    ratings: [
      { d: '04-09', r: 3 }, { d: '04-12', r: 4 }, { d: '04-15', r: 4 },
      { d: '04-19', r: 3 }, { d: '04-22', r: 4 },
    ],
  },
];

const PS_SEED_SHOTS = [
  {
    id: 's1', date: '2026-04-26 08:14', beanId: 'b1', machineId: 'm1', grinderId: 'g1',
    grindSetting: '22', dose: 18.0, yield: 38.2, ratio: 2.12,
    waterTemp: 93, pressure: 9, preInfusion: 7.4, pull: 28.6,
    extraction: 'Perfect', tags: ['Sweet', 'Nutty'], rating: 5,
    notes: 'Best one yet — caramel finish, syrupy mouthfeel.',
  },
  {
    id: 's2', date: '2026-04-26 07:32', beanId: 'b2', machineId: 'm1', grinderId: 'g1',
    grindSetting: '18', dose: 17.0, yield: 42.0, ratio: 2.47,
    waterTemp: 91, pressure: 9, preInfusion: 9.1, pull: 31.4,
    extraction: 'Perfect', tags: ['Floral', 'Sweet'], rating: 5,
    notes: 'Jasmine bloomed on first sip. Lighter, longer ratio.',
  },
  {
    id: 's3', date: '2026-04-25 18:04', beanId: 'b3', machineId: 'm1', grinderId: 'g1',
    grindSetting: '20', dose: 18.0, yield: 35.1, ratio: 1.95,
    waterTemp: 93, pressure: 9, preInfusion: 6.8, pull: 24.2,
    extraction: 'Sour', tags: ['Acidic', 'Sour'], rating: 3,
    notes: 'Pulled too short. Grind finer next time.',
  },
  {
    id: 's4', date: '2026-04-25 09:11', beanId: 'b1', machineId: 'm1', grinderId: 'g1',
    grindSetting: '22', dose: 18.0, yield: 37.8, ratio: 2.10,
    waterTemp: 93, pressure: 9, preInfusion: 7.0, pull: 28.0,
    extraction: 'Perfect', tags: ['Sweet'], rating: 4,
    notes: '',
  },
  {
    id: 's5', date: '2026-04-24 16:22', beanId: 'b3', machineId: 'm2', grinderId: 'g2',
    grindSetting: '12', dose: 18.0, yield: 39.5, ratio: 2.19,
    waterTemp: 92, pressure: 9, preInfusion: 5.4, pull: 33.1,
    extraction: 'Bitter', tags: ['Bitter', 'Smoky'], rating: 2,
    notes: 'Channeled. Distribution issue.',
  },
  {
    id: 's6', date: '2026-04-24 08:48', beanId: 'b2', machineId: 'm1', grinderId: 'g1',
    grindSetting: '18', dose: 17.0, yield: 41.2, ratio: 2.42,
    waterTemp: 91, pressure: 9, preInfusion: 8.7, pull: 30.8,
    extraction: 'Perfect', tags: ['Floral', 'Acidic'], rating: 5,
    notes: '',
  },
];

const PS_TASTING_TAGS = ['Acidic', 'Bitter', 'Sour', 'Sweet', 'Smoky', 'Nutty', 'Floral', 'Perfect'];
const PS_EXTRACTIONS = ['Sour', 'Perfect', 'Bitter'];
const PS_PROCESSES  = ['Washed', 'Natural', 'Honey', 'Wet Hulled', 'Other'];
const PS_ROASTS     = ['Light', 'Medium', 'Dark'];

Object.assign(window, {
  PS_SEED_MACHINES, PS_SEED_GRINDERS, PS_SEED_BEANS, PS_SEED_SHOTS,
  PS_TASTING_TAGS, PS_EXTRACTIONS, PS_PROCESSES, PS_ROASTS,
});
