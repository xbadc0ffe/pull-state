// screens/about.jsx — About sheet

const { useState: useStateAbout } = React;

function PSAboutSheet({ theme, open, onClose, dark, onToggleDark }) {
  const [tipped, setTipped] = useStateAbout(false);
  return (
    <PSSheet open={open} onClose={onClose} theme={theme} title="About">
      <div style={{ padding: '4px 18px 8px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 72, height: 72, borderRadius: 18,
          background: `linear-gradient(160deg, ${theme.accent}, ${theme.accentDeep})`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: theme.shadow,
        }}>
          <svg width="38" height="38" viewBox="0 0 48 48" fill="none">
            <path d="M14 10h20l-2 6H16z" fill="#fff" opacity="0.95"/>
            <path d="M16 16h16l-2 18a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4z" fill="#fff" opacity="0.85"/>
            <circle cx="24" cy="26" r="3.5" fill={theme.accentDeep}/>
          </svg>
        </div>
        <PSDisplay size={26} theme={theme} style={{ whiteSpace: 'nowrap' }}>Pull State</PSDisplay>
        <div style={{ fontFamily: PS_FONTS.mono, fontSize: 11, letterSpacing: 1, color: theme.inkMuted, marginTop: 2, whiteSpace: 'nowrap' }}>
          v 1.0.0 · APR 26 2026
        </div>
      </div>

      <div style={{ padding: '10px 18px 0' }}>
        <PSCard theme={theme}>
          <PSField label="Built by" theme={theme}>
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, color: theme.ink, fontWeight: 600 }}>badc0ffe</span>
          </PSField>
          <PSField label="Contact" theme={theme}>
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, color: theme.accent, fontWeight: 600 }}>info@badc0ffe.net</span>
          </PSField>
          <PSField label="GitHub" theme={theme} style={{ padding: '10px 14px 10px 14px' }} labelFlex="0 0 64px">
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, color: theme.accent, fontWeight: 600, textAlign: 'right', whiteSpace: 'nowrap' }}>github.com/xbadc0ffe/pull-state</span>
          </PSField>
          <PSField label="Appearance" theme={theme} last>
            <ModeSwitch theme={theme} dark={dark} onChange={onToggleDark} />
          </PSField>
        </PSCard>
      </div>

      {/* Tip jar */}
      <div style={{ padding: '18px 18px 0' }}>
        <button
          onClick={() => setTipped(true)}
          disabled={tipped}
          style={{
            appearance: 'none', cursor: tipped ? 'default' : 'pointer',
            width: '100%', padding: '14px 16px',
            display: 'flex', alignItems: 'center', gap: 14,
            background: tipped ? theme.accentSoft : theme.card,
            border: `1px solid ${tipped ? theme.accent : theme.lineStrong}`,
            borderRadius: 14,
            boxShadow: tipped ? 'none' : theme.shadow,
            textAlign: 'left',
            transition: 'all 0.2s ease',
          }}
        >
          <div style={{
            width: 42, height: 42, borderRadius: 12, flexShrink: 0,
            background: tipped ? theme.accent : `linear-gradient(160deg, ${theme.accent}, ${theme.accentDeep})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative',
          }}>
            {tipped ? (
              <div style={{ width: 22, height: 22, color: '#fff' }}>{PS_ICONS.check}</div>
            ) : (
              <React.Fragment>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <path d="M5 9h11v6a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4z" fill="#fff" opacity="0.95"/>
                  <path d="M16 11h2a2 2 0 0 1 0 4h-2" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" fill="none" opacity="0.95"/>
                  <path d="M8 4c0 1.5 1 1.5 1 3M11 4c0 1.5 1 1.5 1 3" stroke="#fff" strokeWidth="1.3" strokeLinecap="round" opacity="0.85"/>
                </svg>
              </React.Fragment>
            )}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontFamily: PS_FONTS.body, fontSize: 14.5, fontWeight: 700,
              color: theme.ink, letterSpacing: 0.1,
            }}>{tipped ? 'Thanks for the coffee!' : 'Buy me a coffee!'}</div>
            <div style={{
              fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkSoft, marginTop: 2,
            }}>{tipped ? 'Means the world. Now back to dialing in.' : 'Support development with a one-time tip.'}</div>
          </div>
          {!tipped && (
            <div style={{
              padding: '7px 12px', borderRadius: 999,
              background: theme.accent, color: '#fff',
              fontFamily: PS_FONTS.mono, fontSize: 13, fontWeight: 700, letterSpacing: 0.3,
              flexShrink: 0,
            }}>$2.99</div>
          )}
        </button>
      </div>

      <div style={{
        margin: '18px 18px 4px', padding: '12px 14px',
        background: theme.surfaceAlt, borderRadius: 12,
        fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkSoft, lineHeight: 1.55,
        textAlign: 'center',
      }}>
        A precision logbook for your espresso practice.<br/>
        Made for people who care about pulls.
      </div>
    </PSSheet>
  );
}

function ModeSwitch({ theme, dark, onChange }) {
  return (
    <div style={{
      display: 'inline-flex', padding: 3, borderRadius: 999,
      background: theme.surfaceAlt, boxShadow: `inset 0 0 0 0.5px ${theme.lineStrong}`,
    }}>
      {[
        { id: false, label: 'Light' },
        { id: true,  label: 'Dark' },
      ].map(opt => {
        const active = dark === opt.id;
        return (
          <button key={String(opt.id)} onClick={() => onChange(opt.id)} style={{
            appearance: 'none', border: 'none', cursor: 'pointer',
            padding: '6px 14px', borderRadius: 999,
            background: active ? theme.accent : 'transparent',
            color: active ? '#fff' : theme.inkSoft,
            fontFamily: PS_FONTS.body, fontSize: 12, fontWeight: 700, letterSpacing: 0.4,
            boxShadow: active ? theme.shadow : 'none',
          }}>{opt.label}</button>
        );
      })}
    </div>
  );
}

Object.assign(window, { PSAboutSheet });
