// screens/beans.jsx — Beans list, detail (with chart), add form, edit recipe

const { useState: useStateBeans } = React;

function PSBeansScreen({ theme, beans, onOpen, onAdd, onShowAbout }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} large title="Beans" subtitle={`${beans.length} BAGS LOGGED`}
        trailing={
          <div style={{ display: 'flex', gap: 6 }}>
            <PSIconBtn icon={PS_ICONS.plus} theme={theme} onClick={onAdd} />
            <PSIconBtn icon={PS_ICONS.more} theme={theme} onClick={onShowAbout} />
          </div>
        } />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 30px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {beans.map(b => (
            <PSCard key={b.id} theme={theme} soft onClick={() => onOpen(b.id)}
              style={{ display: 'flex', padding: 12, gap: 12, alignItems: 'center' }}>
              <PSPhoto theme={theme} src={PS_PHOTOS[b.id]} label="BEAN" radius={10}
                style={{ width: 70, height: 70, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                  <span style={{ fontFamily: PS_FONTS.display, fontSize: 17, fontWeight: 600, color: theme.ink }}>{b.name}</span>
                  <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkMuted }}>#{b.bagNumber}</span>
                </div>
                <div style={{ marginTop: 2, fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkSoft }}>{b.roaster}</div>
                <div style={{ marginTop: 6, display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                  <PSRoastBadge level={b.roast} theme={theme} />
                  <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, color: theme.inkMuted, letterSpacing: 0.6, textTransform: 'uppercase' }}>{b.process}</span>
                  {b.singleOrigin && <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, color: theme.accentDeep, letterSpacing: 0.6 }}>· SINGLE ORIGIN</span>}
                </div>
              </div>
              <div style={{ width: 14, height: 14, color: theme.inkMuted }}>{PS_ICONS.chevron}</div>
            </PSCard>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Bean detail with sparkline rating chart and editable recipe
function PSBeanDetail({ theme, bean, shots, onBack, onUpdateRecipe }) {
  const beanShots = shots.filter(s => s.beanId === bean.id);
  const [editing, setEditing] = useStateBeans(false);
  const [draft, setDraft] = useStateBeans(bean.recipe || defaultRecipe());

  const saveRecipe = () => { onUpdateRecipe(bean.id, draft); setEditing(false); };
  const cancelEdit = () => { setDraft(bean.recipe || defaultRecipe()); setEditing(false); };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} title="Bean"
        leading={<PSIconBtn icon={PS_ICONS.back} theme={theme} onClick={onBack} />} />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 30px' }}>
        <PSPhoto theme={theme} src={PS_PHOTOS[bean.id]} label="BAG PHOTO" style={{ width: '100%', aspectRatio: '4/3', marginBottom: 14 }} radius={14} />
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <PSDisplay size={26} theme={theme}>{bean.name}</PSDisplay>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 12, color: theme.inkMuted }}>BAG #{bean.bagNumber}</span>
        </div>
        <div style={{ marginTop: 4, fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft }}>{bean.roaster}</div>
        <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          <PSRoastBadge level={bean.roast} theme={theme} />
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, color: theme.inkSoft, letterSpacing: 0.6, textTransform: 'uppercase', padding: '3px 7px', border: `0.5px solid ${theme.line}`, borderRadius: 999 }}>{bean.process}</span>
          {bean.singleOrigin && (
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, color: theme.accentDeep, letterSpacing: 0.6, textTransform: 'uppercase', padding: '3px 7px', border: `0.5px solid ${theme.accent}`, borderRadius: 999, background: theme.accentSoft }}>Single origin</span>
          )}
        </div>

        {/* Rating trend chart */}
        <PSSectionLabel theme={theme} style={{ margin: '20px 4px 8px' }}>Rating trend</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 14 }}>
          <RatingChart theme={theme} points={bean.ratings} />
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '18px 4px 8px' }}>Dates</PSSectionLabel>
        <PSCard theme={theme}>
          <PSField label="Roast date" theme={theme}><Mono2>{bean.roastDate}</Mono2></PSField>
          <PSField label="Purchase date" theme={theme} last><Mono2>{bean.purchaseDate}</Mono2></PSField>
        </PSCard>

        {bean.notes && (
          <>
            <PSSectionLabel theme={theme} style={{ margin: '18px 4px 8px' }}>Notes</PSSectionLabel>
            <PSCard theme={theme} style={{ padding: 12 }}>
              <div style={{ fontFamily: PS_FONTS.body, fontSize: 13.5, color: theme.ink, lineHeight: 1.5 }}>{bean.notes}</div>
            </PSCard>
          </>
        )}

        {/* Recipe section */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '18px 4px 8px' }}>
          <PSSectionLabel theme={theme}>Recipe</PSSectionLabel>
          {!editing ? (
            <button onClick={() => { setDraft(bean.recipe || defaultRecipe()); setEditing(true); }} style={{
              appearance: 'none', border: 'none', cursor: 'pointer',
              padding: '5px 10px', borderRadius: 999,
              background: theme.surface, color: theme.accent,
              boxShadow: `inset 0 0 0 0.5px ${theme.lineStrong}`,
              fontFamily: PS_FONTS.body, fontSize: 11, fontWeight: 600,
            }}>Edit</button>
          ) : (
            <div style={{ display: 'flex', gap: 6 }}>
              <button onClick={cancelEdit} style={{
                appearance: 'none', border: 'none', cursor: 'pointer',
                padding: '5px 10px', borderRadius: 999, background: 'transparent', color: theme.inkSoft,
                fontFamily: PS_FONTS.body, fontSize: 11, fontWeight: 600,
              }}>Cancel</button>
              <button onClick={saveRecipe} style={{
                appearance: 'none', border: 'none', cursor: 'pointer',
                padding: '5px 10px', borderRadius: 999, background: theme.accent, color: '#fff',
                fontFamily: PS_FONTS.body, fontSize: 11, fontWeight: 700,
              }}>Save</button>
            </div>
          )}
        </div>
        <RecipeBlock theme={theme} recipe={editing ? draft : (bean.recipe || defaultRecipe())}
          editing={editing} onChange={setDraft} />

        <div style={{ marginTop: 18, fontFamily: PS_FONTS.mono, fontSize: 10, letterSpacing: 1, color: theme.inkMuted, textAlign: 'center' }}>
          {beanShots.length} SHOTS · AVG {beanShots.length ? (beanShots.reduce((s,x)=>s+x.rating,0)/beanShots.length).toFixed(1) : '—'}★
        </div>
      </div>
    </div>
  );
}

function defaultRecipe() {
  return { grind: '', temp: 93, preInfTime: 7, preInfPressure: 3, pullTime: 28, pullPressure: 9 };
}

function RecipeBlock({ theme, recipe, editing, onChange }) {
  const set = (k, v) => onChange({ ...recipe, [k]: v });
  return (
    <PSCard theme={theme}>
      <RecipeRow theme={theme} label="Grind" value={recipe.grind} unit=""
        editing={editing} type="text" onChange={v => set('grind', v)} placeholder="e.g. 22" />
      <RecipeRow theme={theme} label="Water temp" value={recipe.temp} unit="°C"
        editing={editing} type="number" onChange={v => set('temp', v)} />
      <RecipeRow theme={theme} label="Pre-infuse time" value={recipe.preInfTime} unit="s"
        editing={editing} type="number" onChange={v => set('preInfTime', v)} />
      <RecipeRow theme={theme} label="Pre-infuse pressure" value={recipe.preInfPressure} unit="bar"
        editing={editing} type="number" onChange={v => set('preInfPressure', v)} />
      <RecipeRow theme={theme} label="Pull time" value={recipe.pullTime} unit="s"
        editing={editing} type="number" onChange={v => set('pullTime', v)} />
      <RecipeRow theme={theme} label="Pull pressure" value={recipe.pullPressure} unit="bar"
        editing={editing} type="number" onChange={v => set('pullPressure', v)} last />
    </PSCard>
  );
}

function RecipeRow({ theme, label, value, unit, editing, onChange, type = 'text', placeholder, last = false }) {
  return (
    <div style={{
      padding: '11px 14px',
      borderBottom: last ? 'none' : `0.5px solid ${theme.line}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
    }}>
      <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, fontWeight: 500 }}>{label}</span>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, minWidth: 0 }}>
        {editing ? (
          <input type={type === 'number' ? 'text' : 'text'} inputMode={type === 'number' ? 'decimal' : 'text'}
            value={value ?? ''} placeholder={placeholder}
            onChange={(e) => {
              const v = e.target.value;
              if (type === 'number') {
                const n = parseFloat(v);
                onChange(Number.isFinite(n) ? n : v === '' ? '' : value);
              } else { onChange(v); }
            }}
            style={{
              appearance: 'none', border: 'none', outline: 'none',
              background: theme.accentSoft, borderRadius: 6,
              padding: '3px 8px', textAlign: 'right',
              fontFamily: PS_FONTS.mono, fontSize: 13.5, fontWeight: 700, color: theme.ink,
              width: 90,
            }}/>
        ) : (
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13.5, fontWeight: 600, color: theme.ink }}>{value !== '' && value != null ? value : '—'}</span>
        )}
        {unit && <span style={{ fontFamily: PS_FONTS.mono, fontSize: 11, color: theme.inkMuted }}>{unit}</span>}
      </div>
    </div>
  );
}

function Mono2({ children }) {
  return <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, fontWeight: 600 }}>{children}</span>;
}

function RatingChart({ theme, points }) {
  const w = 320, h = 120, pad = 12;
  if (!points || points.length === 0) {
    return <div style={{ fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkMuted }}>No data</div>;
  }
  const xs = points.map((p, i) => pad + i * ((w - pad * 2) / Math.max(points.length - 1, 1)));
  const ys = points.map(p => h - pad - ((p.r - 1) / 4) * (h - pad * 2));
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${xs[i].toFixed(1)} ${ys[i].toFixed(1)}`).join(' ');
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
        {[1,2,3,4,5].map((n) => {
          const y = h - pad - ((n - 1) / 4) * (h - pad * 2);
          return (
            <g key={n}>
              <line x1={pad} y1={y} x2={w - pad} y2={y} stroke={theme.line} strokeWidth="0.5" strokeDasharray={n === 5 || n === 1 ? '0' : '2 3'} />
              <text x={pad - 6} y={y + 3} textAnchor="end" fontFamily={PS_FONTS.mono} fontSize="8" fill={theme.inkMuted}>{n}★</text>
            </g>
          );
        })}
        <path d={`${path} L ${xs[xs.length - 1]} ${h - pad} L ${xs[0]} ${h - pad} Z`}
          fill={theme.accent} fillOpacity="0.12" />
        <path d={path} stroke={theme.accent} strokeWidth="2" fill="none" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={xs[i]} cy={ys[i]} r="3.2" fill={theme.card} stroke={theme.accent} strokeWidth="1.5" />
            <text x={xs[i]} y={h - 2} textAnchor="middle" fontFamily={PS_FONTS.mono} fontSize="8" fill={theme.inkMuted}>{p.d}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}

// ── Add bean form ─────────────────────────────────────────────
function PSBeanAddForm({ theme, nextBagNumber, onCancel, onSave }) {
  const [name, setName] = useStateBeans('');
  const [roaster, setRoaster] = useStateBeans('');
  const [singleOrigin, setSO] = useStateBeans(true);
  const [process, setProcess] = useStateBeans('Washed');
  const [processOther, setProcessOther] = useStateBeans('');
  const [roast, setRoast] = useStateBeans('Medium');
  const [roastDate, setRoastDate] = useStateBeans('2026-04-25');
  const [purchaseDate, setPurchaseDate] = useStateBeans('2026-04-26');
  const [notes, setNotes] = useStateBeans('');
  const [recipe, setRecipe] = useStateBeans(defaultRecipe());

  const finalProcess = process === 'Other' ? (processOther.trim() || 'Other') : process;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} title="Add Bean"
        leading={<button onClick={onCancel} style={{ appearance: 'none', border: 'none', background: 'transparent', color: theme.accent, fontFamily: PS_FONTS.body, fontSize: 14, cursor: 'pointer' }}>Cancel</button>}
        trailing={<button onClick={() => onSave({ name, roaster, singleOrigin, process: finalProcess, roast, roastDate, purchaseDate, notes, recipe })}
          style={{ appearance: 'none', border: 'none', background: 'transparent', color: theme.accent, fontFamily: PS_FONTS.body, fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>Save</button>}
      />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }}>
        <div style={{
          marginBottom: 14, padding: '10px 12px',
          background: theme.accentSoft, border: `0.5px solid ${theme.accent}`, borderRadius: 12,
          fontFamily: PS_FONTS.mono, fontSize: 11, color: theme.accentDeep, letterSpacing: 0.8, fontWeight: 700,
        }}>BAG #{nextBagNumber} · AUTO</div>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Identity</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <PSField label="Bean Name" theme={theme}>
            <PSInput value={name} onChange={setName} theme={theme} placeholder="Black Gold" />
          </PSField>
          <PSField label="Roaster" theme={theme} last>
            <PSInput value={roaster} onChange={setRoaster} theme={theme} placeholder="Onyx Coffee Lab" />
          </PSField>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Single Origin</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft }}>Single Origin</span>
            <Toggle theme={theme} value={singleOrigin} onChange={setSO} />
          </div>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Process</PSSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
          {PS_PROCESSES.map(p => (
            <PSPill key={p} theme={theme} active={process === p} onClick={() => setProcess(p)} style={{ padding: '9px 12px', fontSize: 12 }}>{p}</PSPill>
          ))}
        </div>
        {process === 'Other' && (
          <PSCard theme={theme} style={{ marginBottom: 14 }}>
            <PSField label="Specify process" theme={theme} last>
              <PSInput value={processOther} onChange={setProcessOther} theme={theme} placeholder="e.g. Anaerobic" />
            </PSField>
          </PSCard>
        )}
        {process !== 'Other' && <div style={{ height: 4 }} />}

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Roast Level</PSSectionLabel>
        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          {PS_ROASTS.map(r => (
            <PSPill key={r} theme={theme} active={roast === r} onClick={() => setRoast(r)} style={{ flex: 1, padding: '9px 8px', fontSize: 12 }}>{r}</PSPill>
          ))}
        </div>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Dates</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <PSField label="Roast Date" theme={theme}><PSInput value={roastDate} onChange={setRoastDate} mono theme={theme} /></PSField>
          <PSField label="Purchase Date" theme={theme} last><PSInput value={purchaseDate} onChange={setPurchaseDate} mono theme={theme} /></PSField>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Photo</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 14, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <PSPhoto theme={theme} label="ADD" style={{ width: 56, height: 56 }} radius={10} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.ink, fontWeight: 600 }}>Add a photo</div>
            <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft }}>Helps you spot the bag in your shelf</div>
          </div>
          <div style={{ width: 28, height: 28, color: theme.accent }}>{PS_ICONS.camera}</div>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Notes</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 12, marginBottom: 14 }}>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Tasting notes from the bag…"
            style={{ width: '100%', minHeight: 70, resize: 'vertical', boxSizing: 'border-box',
              border: 'none', outline: 'none', background: 'transparent',
              fontFamily: PS_FONTS.body, fontSize: 13.5, color: theme.ink, lineHeight: 1.5 }}/>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Recipe</PSSectionLabel>
        <RecipeBlock theme={theme} recipe={recipe} editing={true} onChange={setRecipe} />
        <div style={{ height: 14 }} />
      </div>
    </div>
  );
}

function Toggle({ theme, value, onChange }) {
  return (
    <button onClick={() => onChange(!value)} style={{
      appearance: 'none', border: 'none', cursor: 'pointer',
      width: 44, height: 26, borderRadius: 13, padding: 2,
      background: value ? theme.accent : theme.surfaceAlt,
      boxShadow: `inset 0 0 0 0.5px ${theme.lineStrong}`,
      transition: 'all 0.2s',
      display: 'flex', alignItems: 'center',
    }}>
      <div style={{
        width: 22, height: 22, borderRadius: 11,
        background: '#fff',
        transform: value ? 'translateX(18px)' : 'translateX(0)',
        boxShadow: '0 1px 3px rgba(0,0,0,0.25)',
        transition: 'transform 0.2s',
      }} />
    </button>
  );
}

Object.assign(window, { PSBeansScreen, PSBeanDetail, PSBeanAddForm });
