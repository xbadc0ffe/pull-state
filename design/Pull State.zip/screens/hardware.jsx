// screens/hardware.jsx — Espresso machines + grinders, with add modal

const { useState: useStateHW } = React;

function PSHardwareScreen({ theme, machines, grinders, onAdd, onShowAbout }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} large title="Hardware"
        trailing={<PSIconBtn icon={PS_ICONS.more} theme={theme} onClick={onShowAbout} />} />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 30px' }}>
        <SectionHeader theme={theme} title="Espresso Machines" onAdd={() => onAdd('machine')} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 22 }}>
          {machines.map(m => <HardwareCard key={m.id} theme={theme} item={m} />)}
        </div>

        <SectionHeader theme={theme} title="Grinders" onAdd={() => onAdd('grinder')} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {grinders.map(g => <HardwareCard key={g.id} theme={theme} item={g} />)}
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ theme, title, onAdd }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '4px 4px 10px' }}>
      <PSDisplay size={20} theme={theme}>{title}</PSDisplay>
      <button onClick={onAdd} style={{
        appearance: 'none', border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 4,
        padding: '5px 10px', borderRadius: 9999,
        background: theme.accentSoft, color: theme.accentDeep,
        fontFamily: PS_FONTS.body, fontSize: 12, fontWeight: 600,
        border: `0.5px solid ${theme.accent}`,
      }}>
        <div style={{ width: 12, height: 12 }}>{PS_ICONS.plus}</div>
        Add
      </button>
    </div>
  );
}

function HardwareCard({ theme, item }) {
  return (
    <PSCard theme={theme} soft style={{ display: 'flex', padding: 12, gap: 12, alignItems: 'center' }}>
      <PSPhoto theme={theme} src={PS_PHOTOS[item.id]} label="HARDWARE" radius={10}
        style={{ width: 78, height: 78, flexShrink: 0 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: PS_FONTS.display, fontSize: 18, fontWeight: 600, color: theme.ink, letterSpacing: -0.2 }}>{item.name}</div>
        <div style={{ marginTop: 2, fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkSoft }}>{item.brand}</div>
        <div style={{ marginTop: 8, display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '4px 8px', borderRadius: 999,
          background: theme.surface, border: `0.5px solid ${theme.line}` }}>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 11, fontWeight: 700, color: theme.accent }}>{item.shotCount}</span>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9, letterSpacing: 1, color: theme.inkMuted }}>SHOTS</span>
        </div>
      </div>
      <div style={{ width: 14, height: 14, color: theme.inkMuted }}>{PS_ICONS.chevron}</div>
    </PSCard>
  );
}

// ── Add Hardware modal form ──────────────────────────────────
function PSHardwareAddForm({ theme, kind, onCancel, onSave }) {
  const [name, setName] = useStateHW('');
  const [brand, setBrand] = useStateHW('');
  const isMachine = kind === 'machine';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} title={isMachine ? 'Add Machine' : 'Add Grinder'}
        leading={<button onClick={onCancel} style={{ appearance: 'none', border: 'none', background: 'transparent', color: theme.accent, fontFamily: PS_FONTS.body, fontSize: 14, cursor: 'pointer' }}>Cancel</button>}
        trailing={<button onClick={() => onSave({ name: name.trim() || (isMachine ? 'New Machine' : 'New Grinder'), brand: brand.trim() })}
          style={{ appearance: 'none', border: 'none', background: 'transparent', color: theme.accent, fontFamily: PS_FONTS.body, fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>Save</button>}
      />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 24px' }}>
        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>{isMachine ? 'Espresso Machine' : 'Grinder'}</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <PSField label="Name" theme={theme}>
            <PSInput value={name} onChange={setName} theme={theme} placeholder={isMachine ? 'Linea Mini' : 'Niche Zero'} />
          </PSField>
          <PSField label="Brand" theme={theme} last>
            <PSInput value={brand} onChange={setBrand} theme={theme} placeholder={isMachine ? 'La Marzocco' : 'Niche'} />
          </PSField>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Photo</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 14, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
          <PSPhoto theme={theme} label="ADD" style={{ width: 56, height: 56 }} radius={10} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.ink, fontWeight: 600 }}>Add a photo</div>
            <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft }}>Optional · helps when picking on Log</div>
          </div>
          <div style={{ width: 28, height: 28, color: theme.accent }}>{PS_ICONS.camera}</div>
        </PSCard>

        <div style={{
          marginTop: 8, padding: '12px 14px',
          background: theme.surfaceAlt, borderRadius: 12,
          fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkSoft, lineHeight: 1.5,
        }}>
          {isMachine
            ? 'New machines start at 0 shots. Pulling shots on the Log tab will increment this automatically.'
            : 'Grinder shot counts track how many shots have run through this burr set.'}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PSHardwareScreen, PSHardwareAddForm });
