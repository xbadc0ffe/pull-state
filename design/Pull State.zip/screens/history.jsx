// screens/history.jsx — Shot history list + detail view

const { useState: useStateHist, useMemo: useMemoHist } = React;

function PSHistoryScreen({ theme, shots, beans, machines, grinders, onOpenShot, onShowAbout }) {
  const [sortBy, setSortBy] = useStateHist('newest'); // newest, oldest, highest, lowest
  const [filterEx, setFilterEx] = useStateHist(null);
  const [filterRating, setFilterRating] = useStateHist(0);
  const [filterBeanId, setFilterBeanId] = useStateHist(null);
  const [filterMachineId, setFilterMachineId] = useStateHist(null);
  const [filterGrinderId, setFilterGrinderId] = useStateHist(null);
  const [showFilter, setShowFilter] = useStateHist(false);
  const [showSort, setShowSort] = useStateHist(false);

  const totalShots = shots.length;
  const totalGrams = shots.reduce((s, x) => s + x.yield, 0);
  const avgRating = totalShots
    ? (shots.reduce((s, x) => s + x.rating, 0) / totalShots).toFixed(1)
    : '—';

  const filtered = useMemoHist(() => {
    let xs = shots.slice();
    if (filterEx) xs = xs.filter(s => s.extraction === filterEx);
    if (filterRating) xs = xs.filter(s => s.rating >= filterRating);
    if (filterBeanId) xs = xs.filter(s => s.beanId === filterBeanId);
    if (filterMachineId) xs = xs.filter(s => s.machineId === filterMachineId);
    if (filterGrinderId) xs = xs.filter(s => s.grinderId === filterGrinderId);
    if (sortBy === 'newest')   xs.sort((a, b) => b.date.localeCompare(a.date));
    if (sortBy === 'oldest')   xs.sort((a, b) => a.date.localeCompare(b.date));
    if (sortBy === 'highest')  xs.sort((a, b) => b.rating - a.rating);
    if (sortBy === 'lowest')   xs.sort((a, b) => a.rating - b.rating);
    return xs;
  }, [shots, sortBy, filterEx, filterRating, filterBeanId, filterMachineId, filterGrinderId]);

  const filterCount = [filterEx, filterRating, filterBeanId, filterMachineId, filterGrinderId].filter(Boolean).length;
  const clearFilters = () => {
    setFilterEx(null); setFilterRating(0);
    setFilterBeanId(null); setFilterMachineId(null); setFilterGrinderId(null);
  };

  const sortLabels = {
    newest: 'Newest first', oldest: 'Oldest first',
    highest: 'Highest rated', lowest: 'Lowest rated',
  };

  if (shots.length === 0) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
        <PSNavBar theme={theme} large title="History"
          trailing={<PSIconBtn icon={PS_ICONS.more} theme={theme} onClick={onShowAbout} />} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 30, textAlign: 'center' }}>
          <div style={{
            width: 72, height: 72, borderRadius: 36, marginBottom: 16,
            background: theme.surface, border: `0.5px solid ${theme.line}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: theme.inkMuted,
          }}>
            <div style={{ width: 32, height: 32 }}>{PS_ICONS.history}</div>
          </div>
          <PSDisplay size={22} theme={theme}>No shots logged yet</PSDisplay>
          <div style={{ marginTop: 8, fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, maxWidth: 240, lineHeight: 1.5 }}>
            Pull your first shot from the Log tab. It'll show up here with a star next to it.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} large title="History" subtitle={`${totalShots} SHOTS LOGGED`}
        trailing={<PSIconBtn icon={PS_ICONS.more} theme={theme} onClick={onShowAbout} />} />

      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 14px' }}>
        {/* Stats */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          <StatCard theme={theme} label="SHOTS" value={totalShots} />
          <StatCard theme={theme} label="GRAMS" value={totalGrams.toFixed(0)} suffix="g" />
          <StatCard theme={theme} label="AVG ★" value={avgRating} accent />
        </div>

        {/* Compact filter / sort bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <IconChip theme={theme} icon={PS_ICONS.filter} label="Filter"
            badge={filterCount > 0 ? filterCount : null}
            onClick={() => setShowFilter(true)} />
          <IconChip theme={theme} icon={PS_ICONS.sort} label={sortLabels[sortBy]}
            onClick={() => setShowSort(true)} />
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkMuted, letterSpacing: 0.6 }}>
            {filtered.length} / {totalShots}
          </span>
        </div>

        {/* Cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(s => {
            const bean = beans.find(b => b.id === s.beanId);
            return <ShotCard key={s.id} theme={theme} shot={s} bean={bean} onClick={() => onOpenShot(s.id)} />;
          })}
        </div>

        {filtered.length === 0 && (
          <div style={{ padding: 30, textAlign: 'center', fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft }}>
            No shots match your filters.
          </div>
        )}
      </div>

      {/* Filter sheet */}
      <PSSheet open={showFilter} onClose={() => setShowFilter(false)} theme={theme} title="Filter shots">
        <div style={{ padding: '0 18px 8px' }}>
          <PSSectionLabel theme={theme} style={{ margin: '6px 4px 8px' }}>Extraction</PSSectionLabel>
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {PS_EXTRACTIONS.map(e => (
              <PSPill key={e} theme={theme} tone={e.toLowerCase()} active={filterEx === e}
                onClick={() => setFilterEx(filterEx === e ? null : e)}
                style={{ flex: 1, padding: '9px 8px', fontSize: 12 }}>{e}</PSPill>
            ))}
          </div>

          <PSSectionLabel theme={theme} style={{ margin: '6px 4px 8px' }}>Min rating</PSSectionLabel>
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            {[0,2,3,4,5].map(r => (
              <PSPill key={r} theme={theme} active={filterRating === r}
                onClick={() => setFilterRating(r)}
                style={{ flex: 1, padding: '9px 8px', fontSize: 12 }}>
                {r === 0 ? 'Any' : `★${r}+`}
              </PSPill>
            ))}
          </div>

          <PSSectionLabel theme={theme} style={{ margin: '6px 4px 8px' }}>Beans</PSSectionLabel>
          <PSCard theme={theme} style={{ marginBottom: 14 }}>
            <SelectRow theme={theme} label="Any beans"
              options={[{ id: null, label: 'Any beans' }, ...beans.map(b => ({ id: b.id, label: b.name, sub: `#${b.bagNumber} · ${b.roaster}` }))]}
              value={filterBeanId} onChange={setFilterBeanId} last />
          </PSCard>

          <PSSectionLabel theme={theme} style={{ margin: '6px 4px 8px' }}>Machine</PSSectionLabel>
          <PSCard theme={theme} style={{ marginBottom: 14 }}>
            <SelectRow theme={theme} label="Any machine"
              options={[{ id: null, label: 'Any machine' }, ...machines.map(m => ({ id: m.id, label: m.name, sub: m.brand }))]}
              value={filterMachineId} onChange={setFilterMachineId} last />
          </PSCard>

          <PSSectionLabel theme={theme} style={{ margin: '6px 4px 8px' }}>Grinder</PSSectionLabel>
          <PSCard theme={theme} style={{ marginBottom: 14 }}>
            <SelectRow theme={theme} label="Any grinder"
              options={[{ id: null, label: 'Any grinder' }, ...grinders.map(g => ({ id: g.id, label: g.name, sub: g.brand }))]}
              value={filterGrinderId} onChange={setFilterGrinderId} last />
          </PSCard>

          <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
            <button onClick={clearFilters} style={{
              flex: 1, appearance: 'none', border: 'none', cursor: 'pointer',
              padding: '12px', borderRadius: 12,
              background: theme.surface, color: theme.ink,
              boxShadow: `inset 0 0 0 0.5px ${theme.lineStrong}`,
              fontFamily: PS_FONTS.body, fontSize: 13, fontWeight: 600,
            }}>Clear all</button>
            <button onClick={() => setShowFilter(false)} style={{
              flex: 2, appearance: 'none', border: 'none', cursor: 'pointer',
              padding: '12px', borderRadius: 12,
              background: theme.accent, color: '#fff',
              boxShadow: theme.shadow,
              fontFamily: PS_FONTS.body, fontSize: 13, fontWeight: 700, letterSpacing: 0.4,
            }}>Apply</button>
          </div>
        </div>
      </PSSheet>

      {/* Sort sheet */}
      <PSSheet open={showSort} onClose={() => setShowSort(false)} theme={theme} title="Sort by">
        <div style={{ padding: '0 18px 16px' }}>
          {Object.entries(sortLabels).map(([k, lbl]) => (
            <button key={k} onClick={() => { setSortBy(k); setShowSort(false); }}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                width: '100%', padding: '14px 14px',
                appearance: 'none', border: 'none', cursor: 'pointer',
                background: sortBy === k ? theme.accentSoft : theme.card,
                marginBottom: 8, borderRadius: 12,
                boxShadow: `inset 0 0 0 0.5px ${sortBy === k ? theme.accent : theme.line}`,
                fontFamily: PS_FONTS.body, fontSize: 14, fontWeight: 600,
                color: sortBy === k ? theme.accentDeep : theme.ink, textAlign: 'left',
              }}>
              {lbl}
              {sortBy === k && <span style={{ fontFamily: PS_FONTS.mono, fontSize: 12 }}>✓</span>}
            </button>
          ))}
        </div>
      </PSSheet>
    </div>
  );
}

function IconChip({ theme, icon, label, onClick, badge }) {
  return (
    <button onClick={onClick} style={{
      appearance: 'none', border: 'none', cursor: 'pointer',
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '7px 11px', borderRadius: 9999,
      background: badge ? theme.accentSoft : theme.surface,
      color: badge ? theme.accentDeep : theme.ink,
      boxShadow: `inset 0 0 0 0.5px ${badge ? theme.accent : theme.lineStrong}`,
      fontFamily: PS_FONTS.body, fontSize: 12, fontWeight: 600,
      position: 'relative',
    }}>
      <div style={{ width: 13, height: 13 }}>{icon}</div>
      {label}
      {badge ? (
        <span style={{
          marginLeft: 2, minWidth: 16, height: 16, padding: '0 4px',
          borderRadius: 8, background: theme.accent, color: '#fff',
          fontFamily: PS_FONTS.mono, fontSize: 9, fontWeight: 700,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        }}>{badge}</span>
      ) : null}
    </button>
  );
}

function SelectRow({ theme, options, value, onChange, last = false }) {
  const [open, setOpen] = useStateHist(false);
  const cur = options.find(o => o.id === value) || options[0];
  return (
    <>
      <div onClick={() => setOpen(!open)} style={{
        padding: '12px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
        borderBottom: (last && !open) ? 'none' : `0.5px solid ${theme.line}`,
        cursor: 'pointer',
      }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontFamily: PS_FONTS.body, fontSize: 14, fontWeight: 600, color: theme.ink }}>{cur.label}</div>
          {cur.sub && <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft, marginTop: 1 }}>{cur.sub}</div>}
        </div>
        <div style={{ width: 14, height: 14, color: theme.inkMuted, flexShrink: 0, transform: open ? 'rotate(90deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>{PS_ICONS.chevron}</div>
      </div>
      {open && (
        <div style={{ background: theme.surfaceAlt, borderBottom: last ? 'none' : `0.5px solid ${theme.line}` }}>
          {options.map(o => (
            <div key={o.id ?? 'any'} onClick={() => { onChange(o.id); setOpen(false); }} style={{
              padding: '10px 14px 10px 22px', cursor: 'pointer',
              borderTop: `0.5px solid ${theme.line}`,
              display: 'flex', flexDirection: 'column',
              background: o.id === value ? theme.accentSoft : 'transparent',
            }}>
              <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, fontWeight: 600, color: theme.ink }}>{o.label}</span>
              {o.sub && <span style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft }}>{o.sub}</span>}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function StatCard({ theme, label, value, suffix, accent }) {
  return (
    <div style={{
      flex: 1, padding: '10px 12px',
      background: accent ? theme.accentSoft : theme.card,
      border: `0.5px solid ${accent ? theme.accent : theme.line}`,
      borderRadius: 12,
      boxShadow: theme.shadowSoft,
    }}>
      <div style={{ fontFamily: PS_FONTS.mono, fontSize: 9, letterSpacing: 1.2, color: accent ? theme.accentDeep : theme.inkMuted, fontWeight: 700 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 3, marginTop: 3 }}>
        <span style={{ fontFamily: PS_FONTS.display, fontSize: 24, fontWeight: 700, color: theme.ink, letterSpacing: -0.5 }}>{value}</span>
        {suffix && <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkMuted }}>{suffix}</span>}
      </div>
    </div>
  );
}

function ShotCard({ theme, shot, bean, onClick }) {
  const tone = shot.extraction === 'Sour' ? 'sour' : shot.extraction === 'Bitter' ? 'bitter' : 'perfect';
  const dt = shot.date.replace('T', ' ').slice(0, 16);
  return (
    <PSCard theme={theme} onClick={onClick} soft style={{ display: 'flex', padding: 12, gap: 12, alignItems: 'center' }}>
      <PSPhoto theme={theme} src={null} label="SHOT" style={{ width: 64, height: 64, flexShrink: 0 }} radius={10} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, flexWrap: 'wrap' }}>
          <span style={{ fontFamily: PS_FONTS.display, fontSize: 16, fontWeight: 600, color: theme.ink, letterSpacing: -0.2 }}>{(bean?.name || 'Unknown').toUpperCase()}</span>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkMuted }}>#{bean?.bagNumber || 0}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
          <PSStars value={shot.rating} readOnly size={13} theme={theme} />
          <PSPill theme={theme} tone={tone} active style={{ padding: '3px 8px', fontSize: 10 }}>{shot.extraction || '—'}</PSPill>
        </div>
        <div style={{ marginTop: 5, display: 'flex', gap: 10, fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkSoft }}>
          <span>{shot.dose}g → {shot.yield}g</span>
          <span>{shot.pull.toFixed(1)}s</span>
          <span>1:{shot.ratio.toFixed(2)}</span>
        </div>
        <div style={{ marginTop: 3, fontFamily: PS_FONTS.mono, fontSize: 9.5, color: theme.inkMuted, textTransform: 'uppercase', letterSpacing: 0.6 }}>{dt}</div>
      </div>
      <div style={{ width: 14, height: 14, color: theme.inkMuted }}>{PS_ICONS.chevron}</div>
    </PSCard>
  );
}

// Detail
function PSShotDetail({ theme, shot, bean, machine, grinder, onBack }) {
  const tone = shot.extraction === 'Sour' ? 'sour' : shot.extraction === 'Bitter' ? 'bitter' : 'perfect';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} title="Shot detail"
        leading={<PSIconBtn icon={PS_ICONS.back} theme={theme} onClick={onBack} />} />
      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 30px' }}>
        <PSPhoto theme={theme} label="SHOT PHOTO" style={{ width: '100%', aspectRatio: '4/3', marginBottom: 14 }} radius={14} />

        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
          <PSDisplay size={24} theme={theme}>{(bean?.name || 'Unknown')}</PSDisplay>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 12, color: theme.inkMuted }}>#{bean?.bagNumber || 0}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <PSStars value={shot.rating} readOnly size={18} theme={theme} />
          <PSPill theme={theme} tone={tone} active style={{ padding: '5px 10px' }}>{shot.extraction}</PSPill>
        </div>

        <PSSectionLabel theme={theme} style={{ margin: '6px 4px 6px' }}>Numbers</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <PSField label="Pre-infusion" theme={theme}><Mono>{shot.preInfusion.toFixed(1)}s</Mono></PSField>
          <PSField label="Pull time" theme={theme}><Mono>{shot.pull.toFixed(1)}s</Mono></PSField>
          <PSField label="Dose" theme={theme}><Mono>{shot.dose.toFixed(1)}g</Mono></PSField>
          <PSField label="Yield" theme={theme} suffix={`1:${shot.ratio.toFixed(2)}`}><Mono>{shot.yield.toFixed(1)}g</Mono></PSField>
          <PSField label="Grind" theme={theme}><Mono>{shot.grindSetting}</Mono></PSField>
          <PSField label="Water" theme={theme}><Mono>{shot.waterTemp}°C</Mono></PSField>
          <PSField label="Pressure" theme={theme} last><Mono>{shot.pressure} bar</Mono></PSField>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '6px 4px 6px' }}>Hardware</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 14 }}>
          <PSField label="Machine" theme={theme}><Mono>{machine?.name || '—'}</Mono></PSField>
          <PSField label="Grinder" theme={theme} last><Mono>{grinder?.name || '—'}</Mono></PSField>
        </PSCard>

        <PSSectionLabel theme={theme} style={{ margin: '6px 4px 6px' }}>Tasting notes</PSSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 14 }}>
          {shot.tags.length === 0 && <span style={{ fontFamily: PS_FONTS.body, fontSize: 12, color: theme.inkMuted }}>No tags</span>}
          {shot.tags.map(t => <PSPill key={t} theme={theme} active>{t}</PSPill>)}
        </div>

        {shot.notes && (
          <>
            <PSSectionLabel theme={theme} style={{ margin: '6px 4px 6px' }}>Notes</PSSectionLabel>
            <PSCard theme={theme} style={{ padding: 12, marginBottom: 14 }}>
              <div style={{ fontFamily: PS_FONTS.body, fontSize: 13.5, color: theme.ink, lineHeight: 1.5 }}>{shot.notes}</div>
            </PSCard>
          </>
        )}

        <div style={{ marginTop: 8, fontFamily: PS_FONTS.mono, fontSize: 10, color: theme.inkMuted, textAlign: 'center', letterSpacing: 1 }}>
          {shot.date.replace('T', ' · ').slice(0, 19)}
        </div>
      </div>
    </div>
  );
}

function Mono({ children }) {
  return <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13.5, fontWeight: 600 }}>{children}</span>;
}

Object.assign(window, { PSHistoryScreen, PSShotDetail });
