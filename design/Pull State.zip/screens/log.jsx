// screens/log.jsx — Shot logging screen with timer + form

const { useState: useStateLog, useEffect: useEffectLog, useRef: useRefLog } = React;

function PSLogScreen({ theme, machines, grinders, beans, defaults, onSave, onShowAbout }) {
  const [machineId, setMachineId] = useStateLog(defaults.machineId);
  const [grinderId, setGrinderId] = useStateLog(defaults.grinderId);
  const [beanId, setBeanId]       = useStateLog(defaults.beanId);

  // Timer state
  const [tState, setTState]   = useStateLog('idle'); // idle, running, done
  const [phase, setPhase]     = useStateLog('pre');  // pre, pull
  const [tElapsed, setTElapsed] = useStateLog(0);
  const [preEnd, setPreEnd]   = useStateLog(null);
  const [pullEnd, setPullEnd] = useStateLog(null);
  const tickRef = useRefLog(null);
  const startTRef = useRefLog(null);

  useEffectLog(() => {
    if (tState === 'running') {
      startTRef.current = performance.now() - tElapsed * 1000;
      tickRef.current = setInterval(() => {
        setTElapsed((performance.now() - startTRef.current) / 1000);
      }, 67);
      return () => clearInterval(tickRef.current);
    }
  }, [tState]);

  const onStart = () => {
    if (tState === 'idle') {
      setTElapsed(0); setPreEnd(null); setPullEnd(null);
      setPhase('pre'); setTState('running');
    }
  };
  const onFirstDrip = () => {
    if (tState === 'running' && phase === 'pre') {
      setPreEnd(tElapsed); setPhase('pull');
    }
  };
  const onDone = () => {
    if (tState === 'running') {
      if (preEnd == null) setPreEnd(tElapsed);
      setPullEnd(tElapsed);
      setTState('done');
    }
  };
  const onReset = () => {
    setTState('idle'); setPhase('pre');
    setTElapsed(0); setPreEnd(null); setPullEnd(null);
  };

  // Manual value entry — sets preEnd/pullEnd directly and jumps to "done"
  const onManualSet = (kind, secs) => {
    const s = Math.max(0, Math.min(parseFloat(secs) || 0, 999));
    if (kind === 'pre') {
      const newPre = s;
      const currentPull = (pullEnd != null ? pullEnd - (preEnd ?? 0) : 0);
      setPreEnd(newPre);
      setPullEnd(newPre + currentPull);
      setTState('done');
    } else {
      const basePre = preEnd ?? 0;
      if (preEnd == null) setPreEnd(0);
      setPullEnd((preEnd ?? 0) + s);
      setTState('done');
    }
  };

  const preInfusion = preEnd ?? (tState === 'running' && phase === 'pre' ? tElapsed : 0);
  const pullTime = pullEnd != null
    ? pullEnd - (preEnd ?? 0)
    : (tState === 'running' && phase === 'pull' ? tElapsed - (preEnd ?? 0) : 0);

  // Form state
  const [grindSetting, setGrindSetting] = useStateLog('22');
  const [dose, setDose]       = useStateLog(18.0);
  const [yieldG, setYieldG]   = useStateLog(38.0);
  const [waterTemp, setWaterTemp] = useStateLog(93);
  const [pressure, setPressure]   = useStateLog(9);
  const [extraction, setExtraction] = useStateLog(null);
  const [tags, setTags] = useStateLog([]);
  const [rating, setRating] = useStateLog(0);
  const [notes, setNotes] = useStateLog('');
  const [photo, setPhoto] = useStateLog(false);

  const ratio = (parseFloat(yieldG) / parseFloat(dose));

  const machine = machines.find(m => m.id === machineId);
  const grinder = grinders.find(g => g.id === grinderId);
  const bean    = beans.find(b => b.id === beanId);

  const toggleTag = (t) => setTags(tags.includes(t) ? tags.filter(x => x !== t) : [...tags, t]);

  const now = new Date();
  const dateStr = now.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

  const save = () => {
    onSave({
      date: now.toISOString(), beanId, machineId, grinderId,
      grindSetting, dose: parseFloat(dose), yield: parseFloat(yieldG),
      ratio, waterTemp: parseFloat(waterTemp), pressure: parseFloat(pressure),
      preInfusion: preEnd ?? 0, pull: (pullEnd ?? 0) - (preEnd ?? 0),
      extraction, tags, rating, notes,
    });
    onReset();
    setRating(0); setExtraction(null); setTags([]); setNotes(''); setPhoto(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <PSNavBar theme={theme} large title="Log a shot"
        trailing={<PSIconBtn icon={PS_ICONS.more} theme={theme} onClick={onShowAbout} label="More" />}
      />

      <div className="ps-scroll" style={{ flex: 1, overflowY: 'auto', padding: '0 16px 14px' }}>
        {/* Source pickers */}
        <PSSectionLabel theme={theme} style={{ margin: '4px 4px 8px' }}>Source</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 16 }}>
          <PickerRow theme={theme} label="Machine" value={machine?.name || '—'} sub={machine?.brand}
            options={machines.map(m => ({ id: m.id, label: m.name, sub: m.brand }))}
            onPick={setMachineId} />
          <PickerRow theme={theme} label="Grinder" value={grinder?.name || '—'} sub={grinder?.brand}
            options={grinders.map(g => ({ id: g.id, label: g.name, sub: g.brand }))}
            onPick={setGrinderId} />
          <PickerRow theme={theme} last label="Beans" value={bean?.name || '—'} sub={bean ? `${bean.roaster} · #${bean.bagNumber}` : ''}
            options={beans.map(b => ({ id: b.id, label: b.name, sub: `${b.roaster} · #${b.bagNumber}` }))}
            onPick={setBeanId} />
        </PSCard>

        {/* Timer */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Timer</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 16, marginBottom: 16 }}>
          <DualTrackTimer theme={theme} preInfusion={preInfusion} pullTime={pullTime}
            running={tState === 'running'} phase={phase} done={tState === 'done'}
            onManualSet={onManualSet} editable={tState !== 'running'} />
          <div style={{ marginTop: 14 }}>
            {tState !== 'done' ? (
              <div style={{ display: 'flex', gap: 8 }}>
                <TimerBtn theme={theme} label="START" onClick={onStart}
                  disabled={tState !== 'idle'} primary={tState === 'idle'} />
                <TimerBtn theme={theme} label="FIRST DRIP" onClick={onFirstDrip}
                  disabled={!(tState === 'running' && phase === 'pre')} primary={tState === 'running' && phase === 'pre'} />
                <TimerBtn theme={theme} label="DONE" onClick={onDone}
                  disabled={tState !== 'running'} primary={tState === 'running' && phase === 'pull'} />
              </div>
            ) : (
              <button onClick={onReset} style={{
                appearance: 'none', border: 'none', cursor: 'pointer',
                width: '100%', padding: '14px 12px', borderRadius: 12,
                background: theme.surface, color: theme.ink,
                boxShadow: `inset 0 0 0 0.5px ${theme.lineStrong}`,
                fontFamily: PS_FONTS.mono, fontSize: 12, fontWeight: 700, letterSpacing: 1.4,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
                <span style={{ fontSize: 14 }}>↺</span> RESET TIMER
              </button>
            )}
          </div>
        </PSCard>

        {/* Recipe */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Recipe</PSSectionLabel>
        <PSCard theme={theme} style={{ marginBottom: 16, padding: '4px 0' }}>
          <PSField label="Grind Setting" theme={theme}>
            <PSInput value={grindSetting} onChange={setGrindSetting} mono theme={theme} placeholder="22" />
          </PSField>
        </PSCard>
        <PSCard theme={theme} style={{ marginBottom: 16, padding: '10px 14px' }}>
          <SliderField theme={theme} label="Dose / Weight In" value={dose} onChange={setDose}
            min={10} max={25} step={0.1} unit="g" decimals={1} />
          <SliderField theme={theme} label="Yield / Weight Out" value={yieldG} onChange={setYieldG}
            min={15} max={60} step={0.1} unit="g" decimals={1} />
          <SliderField theme={theme} label="Water Temp" value={waterTemp} onChange={setWaterTemp}
            min={85} max={100} step={1} unit="°C" decimals={0} />
          <SliderField theme={theme} label="Pressure" value={pressure} onChange={setPressure}
            min={6} max={12} step={0.5} unit="bar" decimals={1} last />
        </PSCard>

        {/* Extraction */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Extraction</PSSectionLabel>
        <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
          {PS_EXTRACTIONS.map(e => (
            <PSPill key={e} theme={theme} tone={e.toLowerCase()}
              active={extraction === e}
              onClick={() => setExtraction(extraction === e ? null : e)}
              style={{ flex: 1, padding: '11px 8px', fontSize: 13 }}
            >{e}</PSPill>
          ))}
        </div>

        {/* Tasting notes */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Tasting notes</PSSectionLabel>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 18 }}>
          {PS_TASTING_TAGS.map(t => (
            <PSPill key={t} theme={theme} active={tags.includes(t)} onClick={() => toggleTag(t)}>{t}</PSPill>
          ))}
        </div>

        {/* Rating */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Rating</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: '12px 14px', marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft }}>How was it?</span>
          <PSStars value={rating} onChange={setRating} theme={theme} />
        </PSCard>

        {/* Photo + date */}
        <PSCard theme={theme} style={{ marginBottom: 16 }}>
          <div style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            borderBottom: `0.5px solid ${theme.line}` }}>
            <div>
              <div style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, fontWeight: 500 }}>Photo</div>
              <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkMuted }}>{photo ? 'Attached' : 'Optional'}</div>
            </div>
            <button onClick={() => setPhoto(!photo)} style={{
              appearance: 'none', border: 'none', display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 12px', borderRadius: 9999,
              background: photo ? theme.accent : theme.surface,
              color: photo ? '#fff' : theme.ink,
              boxShadow: `inset 0 0 0 0.5px ${theme.line}`,
              fontFamily: PS_FONTS.body, fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}>
              <div style={{ width: 14, height: 14 }}>{PS_ICONS.camera}</div>
              {photo ? 'Attached' : 'Add'}
            </button>
          </div>
          <PSField label="Date / Time" theme={theme} last>
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, color: theme.ink, fontWeight: 600 }}>{dateStr}</span>
          </PSField>
        </PSCard>

        {/* Notes */}
        <PSSectionLabel theme={theme} style={{ margin: '0 4px 8px' }}>Notes</PSSectionLabel>
        <PSCard theme={theme} style={{ padding: 12, marginBottom: 18 }}>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="How does it taste? What changed?"
            style={{
              width: '100%', minHeight: 78, resize: 'vertical', boxSizing: 'border-box',
              border: 'none', outline: 'none', background: 'transparent',
              fontFamily: PS_FONTS.body, fontSize: 13.5, color: theme.ink, lineHeight: 1.45,
            }}/>
        </PSCard>

        {/* Save */}
        <button onClick={save} style={{
          appearance: 'none', border: 'none',
          width: '100%', padding: '17px 16px', borderRadius: 16,
          background: theme.accent, color: '#fff',
          fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 700, letterSpacing: 0.6,
          boxShadow: theme.shadow, cursor: 'pointer',
          marginBottom: 6,
        }}>SAVE SHOT</button>
        <div style={{
          textAlign: 'center', fontFamily: PS_FONTS.mono, fontSize: 9.5, letterSpacing: 1,
          color: theme.inkMuted, padding: '8px 0 4px',
        }}>· · · · · · ·</div>
      </div>
    </div>
  );
}

// ── Slider field with tap-to-edit number override ────────────
function SliderField({ theme, label, value, onChange, min, max, step, unit, decimals = 1, last = false }) {
  const [editing, setEditing] = useStateLog(false);
  const [draft, setDraft] = useStateLog('');
  const v = parseFloat(value);
  // Allow override beyond min/max for manual entry
  const displayMin = Math.min(min, v);
  const displayMax = Math.max(max, v);
  const frac = (v - displayMin) / (displayMax - displayMin || 1);

  const commit = () => {
    const n = parseFloat(draft);
    if (Number.isFinite(n)) onChange(n);
    setEditing(false);
  };

  return (
    <div style={{
      padding: '12px 0', borderBottom: last ? 'none' : `0.5px solid ${theme.line}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8, gap: 8 }}>
        <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, fontWeight: 500 }}>{label}</span>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
          {editing ? (
            <input
              autoFocus
              type="text"
              inputMode="decimal"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onBlur={commit}
              onKeyDown={(e) => { if (e.key === 'Enter') commit(); }}
              style={{
                appearance: 'none', border: 'none', outline: 'none',
                background: theme.accentSoft, borderRadius: 6,
                padding: '2px 6px', textAlign: 'right',
                fontFamily: PS_FONTS.mono, fontSize: 17, fontWeight: 700,
                color: theme.ink, width: 70,
              }}
            />
          ) : (
            <span onClick={() => { setDraft(v.toFixed(decimals)); setEditing(true); }}
              style={{
                fontFamily: PS_FONTS.mono, fontSize: 17, fontWeight: 700,
                color: theme.ink, fontVariantNumeric: 'tabular-nums',
                cursor: 'pointer', padding: '2px 6px', borderRadius: 6,
                borderBottom: `1px dashed ${theme.lineStrong}`,
              }}>{v.toFixed(decimals)}</span>
          )}
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 11, color: theme.inkMuted }}>{unit}</span>
        </div>
      </div>
      <div style={{ position: 'relative', height: 22, display: 'flex', alignItems: 'center' }}>
        <div style={{
          position: 'absolute', left: 0, right: 0, height: 4, borderRadius: 2,
          background: theme.surfaceAlt, border: `0.5px solid ${theme.line}`,
        }}/>
        <div style={{
          position: 'absolute', left: 0, height: 4, borderRadius: 2,
          width: `${Math.max(0, Math.min(100, frac * 100))}%`,
          background: `linear-gradient(90deg, ${theme.accent}, ${theme.accentDeep})`,
        }}/>
        <input type="range"
          min={displayMin} max={displayMax} step={step} value={v}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          style={{
            position: 'absolute', inset: 0, width: '100%', appearance: 'none',
            background: 'transparent', margin: 0, height: 22, cursor: 'pointer',
          }}
          className="ps-range"
        />
      </div>
    </div>
  );
}

function PickerRow({ theme, label, value, sub, options, onPick, last = false }) {
  const [open, setOpen] = useStateLog(false);
  return (
    <>
      <div onClick={() => setOpen(!open)} style={{
        padding: '12px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
        borderBottom: (last && !open) ? 'none' : `0.5px solid ${theme.line}`,
        cursor: 'pointer',
      }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, letterSpacing: 1.2, color: theme.inkMuted, textTransform: 'uppercase' }}>{label}</div>
          <div style={{ fontFamily: PS_FONTS.display, fontSize: 17, fontWeight: 600, color: theme.ink, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{value}</div>
          {sub && <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sub}</div>}
        </div>
        <div style={{ width: 16, height: 16, color: theme.inkMuted, flexShrink: 0, transform: open ? 'rotate(90deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>{PS_ICONS.chevron}</div>
      </div>
      {open && (
        <div style={{ background: theme.surfaceAlt, borderBottom: last ? 'none' : `0.5px solid ${theme.line}` }}>
          {options.map(o => (
            <div key={o.id} onClick={() => { onPick(o.id); setOpen(false); }} style={{
              padding: '10px 14px 10px 22px', cursor: 'pointer',
              borderTop: `0.5px solid ${theme.line}`,
              display: 'flex', flexDirection: 'column',
            }}>
              <span style={{ fontFamily: PS_FONTS.body, fontSize: 13, fontWeight: 600, color: theme.ink }}>{o.label}</span>
              {o.sub && <span style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft }}>{o.sub}</span>}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function TimerBtn({ theme, label, onClick, disabled, primary }) {
  return (
    <button disabled={disabled} onClick={onClick} style={{
      flex: 1, appearance: 'none', border: 'none',
      padding: '12px 6px', borderRadius: 12,
      background: primary ? theme.accent : (disabled ? theme.surfaceAlt : theme.surface),
      color: primary ? '#fff' : (disabled ? theme.inkMuted : theme.ink),
      fontFamily: PS_FONTS.mono, fontSize: 11, fontWeight: 700, letterSpacing: 1,
      boxShadow: primary ? theme.shadow : `inset 0 0 0 0.5px ${theme.line}`,
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.55 : 1,
      transition: 'all 0.2s',
    }}>{label}</button>
  );
}

function DualTrackTimer({ theme, preInfusion, pullTime, running, phase, done, onManualSet, editable }) {
  const preFrac = Math.min(preInfusion / 10, 1);
  const pullFrac = Math.min(pullTime / 30, 1);
  const totalSec = preInfusion + pullTime;
  const preFull = preInfusion >= 10;
  const pullFull = pullTime >= 30;

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
          <div style={{
            fontFamily: PS_FONTS.display, fontWeight: 700, fontSize: 44,
            color: theme.ink, lineHeight: 1, letterSpacing: -1,
            fontVariantNumeric: 'tabular-nums',
          }}>{totalSec.toFixed(1)}</div>
          <div style={{ fontFamily: PS_FONTS.mono, fontSize: 12, color: theme.inkMuted }}>SEC</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {running && (
            <span style={{
              width: 8, height: 8, borderRadius: 4,
              background: theme.accent, animation: 'ps-dot 1.1s ease-in-out infinite',
            }} />
          )}
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, letterSpacing: 1, color: running ? theme.accent : theme.inkMuted, textTransform: 'uppercase', fontWeight: 700 }}>
            {done ? 'DONE' : running ? (phase === 'pre' ? 'PRE-INFUSION' : 'PULLING') : 'READY'}
          </span>
        </div>
      </div>

      <TimerTrack theme={theme} label="PRE-INFUSION" value={preInfusion} fmt="s" frac={preFrac} active={running && phase === 'pre'} accent={theme.accent} dim full={preFull}
        editable={editable} onCommit={(v) => onManualSet && onManualSet('pre', v)} />
      <div style={{ height: 6 }} />
      <TimerTrack theme={theme} label="PULL" value={pullTime} fmt="s" frac={pullFrac} active={running && phase === 'pull'} accent={theme.accent} full={pullFull}
        editable={editable} onCommit={(v) => onManualSet && onManualSet('pull', v)} />
    </div>
  );
}

function TimerTrack({ theme, label, value, fmt, frac, active, accent, dim, full, editable, onCommit }) {
  const [editing, setEditing] = useStateLog(false);
  const [draft, setDraft] = useStateLog('');
  const inputRef = useRefLog(null);

  useEffectLog(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  const begin = () => {
    if (!editable) return;
    setDraft(value > 0 ? value.toFixed(1) : '');
    setEditing(true);
  };
  const commit = () => {
    if (draft !== '' && !isNaN(parseFloat(draft))) {
      onCommit && onCommit(draft);
    }
    setEditing(false);
  };
  const cancel = () => setEditing(false);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4, gap: 8 }}>
        <span style={{ fontFamily: PS_FONTS.mono, fontSize: 9.5, letterSpacing: 1.2, color: active ? accent : theme.inkMuted, fontWeight: 700, whiteSpace: 'nowrap' }}>{label}</span>
        {editing ? (
          <span style={{ display: 'inline-flex', alignItems: 'baseline', gap: 2 }}>
            <input
              ref={inputRef}
              type="number"
              inputMode="decimal"
              step="0.1"
              min="0"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onBlur={commit}
              onKeyDown={(e) => {
                if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); }
                else if (e.key === 'Escape') { e.preventDefault(); cancel(); }
              }}
              style={{
                appearance: 'textfield', WebkitAppearance: 'none',
                width: 56, padding: '2px 6px', textAlign: 'right',
                border: `1px solid ${accent}`, outline: 'none',
                background: theme.card, borderRadius: 6,
                fontFamily: PS_FONTS.mono, fontSize: 13, fontWeight: 600,
                color: theme.ink, fontVariantNumeric: 'tabular-nums',
              }}
            />
            <span style={{ fontFamily: PS_FONTS.mono, fontSize: 13, fontWeight: 600, color: theme.inkSoft }}>{fmt}</span>
          </span>
        ) : (
          <button
            type="button"
            onClick={begin}
            disabled={!editable}
            style={{
              appearance: 'none', border: 'none', background: 'transparent',
              padding: '2px 4px', margin: '-2px -4px',
              cursor: editable ? 'pointer' : 'default',
              fontFamily: PS_FONTS.mono, fontSize: 13, fontWeight: 600,
              color: theme.ink, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap',
              borderRadius: 4,
              borderBottom: editable ? `1px dashed ${theme.lineStrong}` : 'none',
            }}
            title={editable ? 'Tap to enter a value' : ''}
          >{value.toFixed(1)}{fmt}</button>
        )}
      </div>
      <div style={{
        height: 8, borderRadius: 4, background: theme.surfaceAlt,
        overflow: 'hidden', position: 'relative',
        border: `0.5px solid ${theme.line}`,
      }}>
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0,
          width: `${frac * 100}%`,
          background: dim
            ? `linear-gradient(90deg, ${accent}aa, ${accent})`
            : `linear-gradient(90deg, ${accent}, ${theme.accentDeep})`,
          transition: 'width 0.08s linear',
          boxShadow: active ? `0 0 8px ${accent}66` : 'none',
          animation: full && active ? 'ps-trackpulse 1s ease-in-out infinite' : 'none',
        }} />
      </div>
    </div>
  );
}

Object.assign(window, { PSLogScreen });
