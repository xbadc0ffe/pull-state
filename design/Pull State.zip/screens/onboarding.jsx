// screens/onboarding.jsx — first-time setup splash flow

const { useState: useStateOnb } = React;

function PSOnboarding({ theme, onFinish, onSkip }) {
  const [step, setStep] = useStateOnb(0);
  const [machine, setMachine] = useStateOnb({ name: '', brand: '' });
  const [grinder, setGrinder] = useStateOnb({ name: '', brand: '' });
  const [bean, setBean]       = useStateOnb({ name: '', roaster: '', roast: 'Medium' });

  const steps = ['welcome', 'hardware', 'bean', 'ready'];
  const stepKey = steps[step];
  const next = () => setStep(s => Math.min(s + 1, steps.length - 1));
  const back = () => setStep(s => Math.max(s - 1, 0));

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 30,
      display: 'flex', flexDirection: 'column',
      background: theme.page,
    }}>
      {/* progress dots */}
      <div style={{
        display: 'flex', justifyContent: 'center', gap: 6,
        padding: '14px 0 8px',
      }}>
        {steps.map((s, i) => (
          <div key={s} style={{
            width: i === step ? 22 : 6, height: 6, borderRadius: 3,
            background: i <= step ? theme.accent : theme.lineStrong,
            transition: 'all 0.25s ease',
          }} />
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '8px 22px 8px' }} className="ps-scroll">
        {stepKey === 'welcome' && <OnbWelcome theme={theme} />}
        {stepKey === 'hardware' && <OnbHardware theme={theme} machine={machine} setMachine={setMachine} grinder={grinder} setGrinder={setGrinder} />}
        {stepKey === 'bean' && <OnbBean theme={theme} bean={bean} setBean={setBean} />}
        {stepKey === 'ready' && <OnbReady theme={theme} machine={machine} grinder={grinder} bean={bean} />}
      </div>

      {/* footer actions */}
      <div style={{ padding: '10px 22px 28px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button onClick={step === steps.length - 1 ? onFinish : next} style={{
          appearance: 'none', border: 'none',
          padding: '15px 16px', borderRadius: 14,
          background: theme.accent, color: '#fff',
          fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 700, letterSpacing: 0.4,
          boxShadow: theme.shadow,
          cursor: 'pointer',
        }}>
          {stepKey === 'welcome' && 'BEGIN SETUP'}
          {stepKey === 'hardware' && 'CONTINUE'}
          {stepKey === 'bean' && 'CONTINUE'}
          {stepKey === 'ready' && 'PULL YOUR FIRST SHOT'}
        </button>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          {step > 0 ? (
            <button onClick={back} style={{
              appearance: 'none', border: 'none', background: 'transparent',
              color: theme.inkSoft, fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 500, cursor: 'pointer',
              whiteSpace: 'nowrap',
            }}>‹ Back</button>
          ) : <span/>}
          <button onClick={onSkip} style={{
            appearance: 'none', border: 'none', background: 'transparent',
            color: theme.inkMuted, fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 500, cursor: 'pointer',
            textDecoration: 'underline', textUnderlineOffset: 3,
            whiteSpace: 'nowrap',
          }}>Skip setup</button>
        </div>
      </div>
    </div>
  );
}

function OnbWelcome({ theme }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '20px 0 0' }}>
      {/* logo / mark */}
      <div style={{
        width: 92, height: 92, borderRadius: 20,
        background: `linear-gradient(160deg, ${theme.accent}, ${theme.accentDeep})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: theme.shadow, marginBottom: 22,
      }}>
        <svg width="46" height="46" viewBox="0 0 48 48" fill="none">
          <path d="M14 10h20l-2 6H16z" fill="#fff" opacity="0.95"/>
          <path d="M16 16h16l-2 18a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4z" fill="#fff" opacity="0.85"/>
          <circle cx="24" cy="26" r="3.5" fill={theme.accentDeep}/>
        </svg>
      </div>
      <PSDisplay size={34} theme={theme} style={{ textAlign: 'center', whiteSpace: 'nowrap' }}>Pull State</PSDisplay>
      <div style={{
        marginTop: 14, fontFamily: PS_FONTS.body, fontSize: 14,
        color: theme.inkSoft, maxWidth: 280, lineHeight: 1.5,
      }}>
        A precision logbook for your espresso practice. Track every shot, dial in your beans, watch yourself improve.
      </div>
      <div style={{
        marginTop: 30, padding: '18px 18px', borderRadius: 14,
        background: theme.surface, border: `0.5px solid ${theme.line}`,
        textAlign: 'left', width: '100%', boxSizing: 'border-box',
      }}>
        <div style={{
          fontFamily: PS_FONTS.mono, fontSize: 12, letterSpacing: 1.4,
          color: theme.inkSoft, fontWeight: 700, textTransform: 'uppercase',
        }}>Three quick steps</div>
        <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            ['Your hardware', 'Add your machine and grinder.'],
            ['Your bean', 'Log the bag you’re currently pulling.'],
            ['Your first shot', 'Time the pull, log the data, taste it.'],
          ].map(([t, d], i) => (
            <div key={t} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <div style={{
                width: 24, height: 24, borderRadius: 12,
                background: theme.accentSoft, color: theme.accent,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: PS_FONTS.mono, fontSize: 12, fontWeight: 700,
                flexShrink: 0, marginTop: 1,
              }}>{i + 1}</div>
              <div>
                <div style={{ fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 600, color: theme.ink }}>{t}</div>
                <div style={{ fontFamily: PS_FONTS.body, fontSize: 13.5, color: theme.inkSoft, lineHeight: 1.4, marginTop: 1 }}>{d}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function OnbField({ label, value, onChange, theme, placeholder }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
      <PSSectionLabel theme={theme}>{label}</PSSectionLabel>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} style={{
        appearance: 'none', border: 'none', outline: 'none',
        background: theme.card, borderBottom: `1px solid ${theme.lineStrong}`,
        borderRadius: 8, padding: '10px 12px',
        fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 500, color: theme.ink,
      }}/>
    </div>
  );
}

function OnbCombobox({ label, value, onChange, theme, placeholder, options }) {
  const [open, setOpen] = useStateOnb(false);
  const [query, setQuery] = useStateOnb(value || '');
  const wrapRef = React.useRef(null);

  // keep query in sync when value changes externally
  React.useEffect(() => { setQuery(value || ''); }, [value]);

  // close on outside click
  React.useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const filtered = options.filter(o => o.toLowerCase().includes((query || '').toLowerCase()));
  const showList = open;

  return (
    <div ref={wrapRef} style={{ display: 'flex', flexDirection: 'column', gap: 5, position: 'relative' }}>
      <PSSectionLabel theme={theme}>{label}</PSSectionLabel>
      <div style={{ position: 'relative' }}>
        <input
          value={query}
          placeholder={placeholder}
          onFocus={() => setOpen(true)}
          onChange={(e) => { setQuery(e.target.value); onChange(e.target.value); setOpen(true); }}
          style={{
            appearance: 'none', outline: 'none',
            background: theme.card,
            border: `1px solid ${open ? theme.accent : theme.lineStrong}`,
            borderRadius: 10, padding: '11px 36px 11px 12px',
            fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 500, color: theme.ink,
            width: '100%', boxSizing: 'border-box',
            transition: 'border-color 0.15s ease',
          }}
        />
        <button
          type="button"
          onMouseDown={(e) => { e.preventDefault(); setOpen(o => !o); }}
          aria-label="Show options"
          style={{
            position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)',
            appearance: 'none', border: 'none', background: 'transparent',
            width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', color: theme.inkSoft,
          }}
        >
          <svg width="12" height="8" viewBox="0 0 12 8" fill="none" style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.15s ease' }}>
            <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>

      {showList && (
        <div className="ps-scroll" style={{
          position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, zIndex: 5,
          background: theme.card,
          border: `0.5px solid ${theme.lineStrong}`,
          borderRadius: 12, boxShadow: theme.shadow,
          maxHeight: 196, overflowY: 'auto',
          padding: 4,
        }}>
          {filtered.length === 0 && (
            <div style={{
              padding: '10px 12px',
              fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkMuted,
            }}>No matches — keep typing to add a custom name.</div>
          )}
          {filtered.map((opt) => {
            const active = opt === value;
            return (
              <button
                key={opt}
                type="button"
                onMouseDown={(e) => { e.preventDefault(); onChange(opt); setQuery(opt); setOpen(false); }}
                style={{
                  appearance: 'none', border: 'none', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  width: '100%', textAlign: 'left',
                  padding: '10px 12px', borderRadius: 8,
                  background: active ? theme.accentSoft : 'transparent',
                  color: active ? theme.accentDeep : theme.ink,
                  fontFamily: PS_FONTS.body, fontSize: 14, fontWeight: active ? 600 : 500,
                  whiteSpace: 'nowrap', overflow: 'hidden',
                }}
                onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = theme.surfaceAlt; }}
                onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
              >
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{opt}</span>
                {active && <span style={{ width: 14, height: 14, color: theme.accent, flexShrink: 0 }}>{PS_ICONS.check}</span>}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function OnbHardware({ theme, machine, setMachine, grinder, setGrinder }) {
  const machineSuggestions = ['Linea Mini', 'Linea Micra', 'GS3', 'Bambino Plus', 'Silvia Pro', 'Profitec Pro 600', 'Lelit Bianca', 'Rancilio Silvia', 'ECM Synchronika', 'Rocket Appartamento', 'Decent DE1+', 'Flair 58', 'Breville Dual Boiler'];
  const grinderSuggestions = ['Niche Zero', 'Niche Duo', 'DF64', 'DF83', 'Mahlkönig X54', 'Mahlkönig E80', 'Eureka Mignon Specialita', 'Eureka Atom 75', 'Lagom P64', 'Weber Key', 'Baratza Sette 270', 'Fellow Ode'];
  return (
    <div style={{ paddingTop: 12 }}>
      <PSDisplay size={28} theme={theme}>Your hardware</PSDisplay>
      <div style={{ marginTop: 6, fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, lineHeight: 1.5 }}>
        Tell Pull State what you’re pulling on. You can add more later.
      </div>

      <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <PSSectionLabel theme={theme}>Espresso Machine</PSSectionLabel>
          <OnbCombobox label="Name" theme={theme} value={machine.name}
            onChange={(v) => setMachine({...machine, name: v})}
            placeholder="Search or type a model…"
            options={machineSuggestions} />
          <OnbField label="Brand" theme={theme} value={machine.brand} onChange={(v) => setMachine({...machine, brand: v})} placeholder="e.g. La Marzocco" />
        </div>

        <div style={{ height: 1, background: theme.line }} />

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <PSSectionLabel theme={theme}>Grinder</PSSectionLabel>
          <OnbCombobox label="Name" theme={theme} value={grinder.name}
            onChange={(v) => setGrinder({...grinder, name: v})}
            placeholder="Search or type a model…"
            options={grinderSuggestions} />
          <OnbField label="Brand" theme={theme} value={grinder.brand} onChange={(v) => setGrinder({...grinder, brand: v})} placeholder="e.g. Niche" />
        </div>
      </div>
    </div>
  );
}

function OnbBean({ theme, bean, setBean }) {
  return (
    <div style={{ paddingTop: 12 }}>
      <PSDisplay size={28} theme={theme}>What’s in the hopper?</PSDisplay>
      <div style={{ marginTop: 6, fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, lineHeight: 1.5 }}>
        Log your current bag. Bag #1 starts your collection.
      </div>

      <div style={{ marginTop: 22, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <OnbField label="Bean Name" theme={theme} value={bean.name} onChange={(v) => setBean({...bean, name: v})} placeholder="e.g. Black Gold" />
        <OnbField label="Roaster" theme={theme} value={bean.roaster} onChange={(v) => setBean({...bean, roaster: v})} placeholder="e.g. Onyx Coffee Lab" />

        <div>
          <PSSectionLabel theme={theme}>Roast Level</PSSectionLabel>
          <div style={{ marginTop: 8, display: 'flex', gap: 6 }}>
            {PS_ROASTS.map(r => (
              <PSPill key={r} theme={theme} active={bean.roast === r} onClick={() => setBean({...bean, roast: r})}>{r}</PSPill>
            ))}
          </div>
        </div>

        <div style={{
          padding: 14, borderRadius: 12,
          background: theme.accentSoft,
          border: `0.5px solid ${theme.accent}`,
          color: theme.ink, fontFamily: PS_FONTS.body, fontSize: 12.5, lineHeight: 1.5,
        }}>
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 10, letterSpacing: 1, color: theme.accentDeep, fontWeight: 700 }}>BAG #001</span>
          <div style={{ marginTop: 4 }}>
            Bag numbers auto-increment. Photos, dates and tasting notes can be added on the bean page later.
          </div>
        </div>
      </div>
    </div>
  );
}

function OnbReady({ theme, machine, grinder, bean }) {
  return (
    <div style={{ paddingTop: 22, textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div style={{
        width: 76, height: 76, borderRadius: 38,
        background: theme.accentSoft,
        border: `1px solid ${theme.accent}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: theme.accent, marginBottom: 18,
      }}>
        <div style={{ width: 40, height: 40 }}>{PS_ICONS.check}</div>
      </div>
      <PSDisplay size={32} theme={theme}>You’re dialed.</PSDisplay>
      <div style={{ marginTop: 8, fontFamily: PS_FONTS.body, fontSize: 13, color: theme.inkSoft, maxWidth: 260, lineHeight: 1.5 }}>
        Your setup is saved. Time to pull your first shot.
      </div>

      <div style={{ marginTop: 22, width: '100%', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <SummaryRow theme={theme} label="MACHINE" value={machine.name || '—'} sub={machine.brand} />
        <SummaryRow theme={theme} label="GRINDER" value={grinder.name || '—'} sub={grinder.brand} />
        <SummaryRow theme={theme} label="BEAN" value={bean.name || '—'} sub={`${bean.roaster || '—'} · ${bean.roast}`} />
      </div>
    </div>
  );
}

function SummaryRow({ theme, label, value, sub }) {
  return (
    <div style={{
      padding: '12px 14px', borderRadius: 12,
      background: theme.card, border: `0.5px solid ${theme.line}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    }}>
      <div>
        <PSSectionLabel theme={theme}>{label}</PSSectionLabel>
        <div style={{ fontFamily: PS_FONTS.display, fontWeight: 600, fontSize: 18, color: theme.ink, marginTop: 2 }}>{value}</div>
        {sub && <div style={{ fontFamily: PS_FONTS.body, fontSize: 11, color: theme.inkSoft, marginTop: 1 }}>{sub}</div>}
      </div>
      <div style={{ width: 18, height: 18, color: theme.accent }}>{PS_ICONS.check}</div>
    </div>
  );
}

Object.assign(window, { PSOnboarding });
