// theme.jsx — color tokens & shared style helpers

const PS_THEME = {
  light: {
    page: '#ebe2d5',         // paper / cream leather
    surface: '#f4ecdf',      // panel
    surfaceAlt: '#e8dcc8',   // sunken
    card: '#fbf6ec',
    line: 'rgba(58,32,18,0.12)',
    lineStrong: 'rgba(58,32,18,0.22)',
    ink: '#2a1c14',
    inkSoft: 'rgba(42,28,20,0.68)',
    inkMuted: 'rgba(42,28,20,0.42)',
    accent: '#C8794A',       // CREMA
    accentDeep: '#9a5430',
    accentSoft: 'rgba(200,121,74,0.14)',
    good: '#5d7a3f',
    bad: '#a14a3a',
    chrome: '#dccbb1',       // tab bar bg
    shadow: '0 1px 0 rgba(255,255,255,0.6) inset, 0 1px 2px rgba(58,32,18,0.10), 0 8px 24px rgba(58,32,18,0.10)',
    shadowSoft: '0 1px 0 rgba(255,255,255,0.6) inset, 0 1px 2px rgba(58,32,18,0.06)',
    placeholder: 'repeating-linear-gradient(45deg, #d6c4a8 0 6px, #cfbb9a 6px 12px)',
  },
  dark: {
    page: '#1a1411',
    surface: '#241b16',
    surfaceAlt: '#1f1612',
    card: '#2a201a',
    line: 'rgba(244,237,228,0.08)',
    lineStrong: 'rgba(244,237,228,0.16)',
    ink: '#f4ede4',
    inkSoft: 'rgba(244,237,228,0.66)',
    inkMuted: 'rgba(244,237,228,0.40)',
    accent: '#D88B5A',
    accentDeep: '#C8794A',
    accentSoft: 'rgba(216,139,90,0.16)',
    good: '#9bbf6f',
    bad: '#d97a64',
    chrome: '#150f0c',
    shadow: '0 1px 0 rgba(255,255,255,0.04) inset, 0 1px 2px rgba(0,0,0,0.5), 0 14px 30px rgba(0,0,0,0.5)',
    shadowSoft: '0 1px 0 rgba(255,255,255,0.03) inset, 0 1px 2px rgba(0,0,0,0.45)',
    placeholder: 'repeating-linear-gradient(45deg, #3a2c22 0 6px, #2e231b 6px 12px)',
  },
};

const PS_FONTS = {
  display: '"Fraunces", Georgia, serif',
  body: '"Inter Tight", -apple-system, system-ui, sans-serif',
  mono: '"JetBrains Mono", ui-monospace, Menlo, monospace',
};

// Format mm:ss.ms (or s.s)
function psFmtTime(sec) {
  if (!Number.isFinite(sec)) sec = 0;
  if (sec < 60) {
    return sec.toFixed(1) + 's';
  }
  const m = Math.floor(sec / 60);
  const s = (sec - m * 60).toFixed(1);
  return `${m}:${s.padStart(4, '0')}`;
}

Object.assign(window, { PS_THEME, PS_FONTS, psFmtTime });
