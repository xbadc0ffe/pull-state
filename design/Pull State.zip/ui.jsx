// ui.jsx — shared visual primitives (Pull State design language)

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ── Imagery placeholder ────────────────────────────────────────
function PSPlaceholder({ kind = 'shot', label, theme, style = {}, radius = 10 }) {
  return (
    <div style={{
      position: 'relative', overflow: 'hidden', borderRadius: radius,
      background: theme.placeholder,
      border: `0.5px solid ${theme.line}`,
      ...style,
    }}>
      {/* darker vignette so label is readable */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(135deg, rgba(0,0,0,0.10), rgba(0,0,0,0.25))',
      }} />
      {label && (
        <div style={{
          position: 'absolute', left: 6, bottom: 6,
          fontFamily: PS_FONTS.mono, fontSize: 8, letterSpacing: 0.6,
          color: '#fff', textTransform: 'uppercase',
          background: 'rgba(0,0,0,0.55)', padding: '2px 5px', borderRadius: 3,
        }}>{label}</div>
      )}
    </div>
  );
}

// ── A photo "thumbnail" — uses Unsplash for beans/hardware, placeholder otherwise
function PSPhoto({ src, alt, theme, label, style = {}, radius = 10 }) {
  if (src) {
    return (
      <div style={{
        position: 'relative', overflow: 'hidden', borderRadius: radius,
        background: theme.surfaceAlt,
        border: `0.5px solid ${theme.line}`,
        ...style,
      }}>
        <img src={src} alt={alt || ''} style={{
          width: '100%', height: '100%', objectFit: 'cover', display: 'block',
        }} onError={(e) => { e.currentTarget.style.display = 'none'; }} />
      </div>
    );
  }
  return <PSPlaceholder kind="generic" label={label} theme={theme} style={style} radius={radius} />;
}

// ── Card / panel ──────────────────────────────────────────────
function PSCard({ children, theme, style = {}, soft = false, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: theme.card,
        border: `0.5px solid ${theme.line}`,
        borderRadius: 14,
        boxShadow: soft ? theme.shadowSoft : theme.shadow,
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ── Section label (small caps / mono)
function PSSectionLabel({ children, theme, style = {} }) {
  return (
    <div style={{
      fontFamily: PS_FONTS.mono, fontSize: 10, fontWeight: 500,
      letterSpacing: 1.4, textTransform: 'uppercase',
      color: theme.inkMuted,
      ...style,
    }}>{children}</div>
  );
}

// ── Display title (serif)
function PSDisplay({ children, size = 28, theme, style = {} }) {
  return (
    <div style={{
      fontFamily: PS_FONTS.display, fontSize: size, fontWeight: 600,
      letterSpacing: -0.3, color: theme.ink,
      lineHeight: 1.05, ...style,
    }}>{children}</div>
  );
}

// ── Pill (extraction, tags) ───────────────────────────────────
function PSPill({ children, active = false, tone = 'neutral', theme, onClick, style = {} }) {
  const palette = {
    neutral: { bg: theme.surface, fg: theme.inkSoft, ring: theme.line, abg: theme.accent, afg: '#fff', aring: theme.accent },
    sour:    { bg: theme.surface, fg: theme.inkSoft, ring: theme.line, abg: theme.bad, afg: '#fff', aring: theme.bad },
    perfect: { bg: theme.surface, fg: theme.inkSoft, ring: theme.line, abg: theme.good, afg: '#fff', aring: theme.good },
    bitter:  { bg: theme.surface, fg: theme.inkSoft, ring: theme.line, abg: '#5d3a25', afg: '#fff', aring: '#5d3a25' },
  }[tone];
  return (
    <button onClick={onClick} style={{
      appearance: 'none', border: 'none',
      padding: '7px 12px', borderRadius: 9999,
      fontFamily: PS_FONTS.body, fontSize: 12, fontWeight: 600, letterSpacing: 0.2,
      background: active ? palette.abg : palette.bg,
      color: active ? palette.afg : palette.fg,
      boxShadow: active
        ? `inset 0 -1px 0 rgba(0,0,0,0.18), 0 1px 2px rgba(0,0,0,0.15)`
        : `inset 0 0 0 0.5px ${palette.ring}`,
      cursor: onClick ? 'pointer' : 'default',
      transition: 'all 0.15s ease',
      ...style,
    }}>{children}</button>
  );
}

// ── Stars ─────────────────────────────────────────────────────
function PSStars({ value = 0, onChange, size = 22, theme, readOnly = false }) {
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1,2,3,4,5].map(n => {
        const filled = n <= value;
        return (
          <button key={n}
            onClick={() => !readOnly && onChange && onChange(n === value ? 0 : n)}
            style={{
              appearance: 'none', background: 'none', border: 'none',
              padding: 0, cursor: readOnly ? 'default' : 'pointer',
              color: filled ? theme.accent : theme.inkMuted,
              transition: 'color 0.15s, transform 0.15s',
            }}
            aria-label={`${n} stars`}
          >
            <svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round">
              <path d="M12 2.5l2.92 6.32 6.83.65-5.18 4.74 1.55 6.79L12 17.6l-6.12 3.4 1.55-6.79L2.25 9.47l6.83-.65L12 2.5z"/>
            </svg>
          </button>
        );
      })}
    </div>
  );
}

// ── Field row (label + value/input) ───────────────────────────
function PSField({ label, children, theme, suffix, last = false, style = {}, labelFlex }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', minHeight: 50,
      padding: '10px 14px',
      borderBottom: last ? 'none' : `0.5px solid ${theme.line}`,
      ...style,
    }}>
      <div style={{
        flex: labelFlex || '0 0 42%', fontFamily: PS_FONTS.body, fontSize: 13,
        color: theme.inkSoft, fontWeight: 500,
      }}>{label}</div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'flex-end' }}>
        {children}
        {suffix && (
          <span style={{ fontFamily: PS_FONTS.mono, fontSize: 11, color: theme.inkMuted }}>{suffix}</span>
        )}
      </div>
    </div>
  );
}

// numeric / text input that visually disappears into the row
function PSInput({ value, onChange, theme, placeholder, type = 'text', mono = false, align = 'right', style = {} }) {
  return (
    <input
      value={value ?? ''}
      placeholder={placeholder}
      type={type}
      onChange={(e) => onChange && onChange(e.target.value)}
      style={{
        appearance: 'none', border: 'none', outline: 'none',
        background: 'transparent', textAlign: align,
        fontFamily: mono ? PS_FONTS.mono : PS_FONTS.body,
        fontSize: 15, fontWeight: 600,
        color: theme.ink, width: '100%',
        ...style,
      }}
    />
  );
}

// ── Roast badge (warm pip swatch + text)
function PSRoastBadge({ level, theme, style = {} }) {
  const colors = {
    Light:  '#cea16d',
    Medium: '#7d4a26',
    Dark:   '#3a1f12',
  };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontFamily: PS_FONTS.mono, fontSize: 9.5, letterSpacing: 0.8,
      textTransform: 'uppercase', color: theme.inkSoft,
      padding: '3px 7px', borderRadius: 999,
      border: `0.5px solid ${theme.line}`,
      background: theme.surface,
      ...style,
    }}>
      <span style={{
        width: 7, height: 7, borderRadius: '50%',
        background: colors[level] || colors.Medium,
        boxShadow: 'inset 0 0 1px rgba(0,0,0,0.25)',
      }} />
      {level}
    </span>
  );
}

// ── Top nav bar (custom, replaces IOSNavBar so we can match brand)
function PSNavBar({ title, theme, leading, trailing, large = false, subtitle }) {
  return (
    <div style={{
      padding: large ? '10px 16px 6px' : '6px 12px',
      display: 'flex', flexDirection: 'column',
      gap: large ? 6 : 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', minHeight: 36 }}>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-start', gap: 8 }}>
          {leading}
        </div>
        {!large && (
          <div style={{
            position: 'absolute', left: 0, right: 0, textAlign: 'center', pointerEvents: 'none',
            fontFamily: PS_FONTS.body, fontSize: 15, fontWeight: 600, color: theme.ink,
          }}>{title}</div>
        )}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 8 }}>
          {trailing}
        </div>
      </div>
      {large && (
        <div style={{ padding: '4px 4px 10px' }}>
          <PSDisplay size={32} theme={theme}>{title}</PSDisplay>
          {subtitle && <div style={{
            marginTop: 4, fontFamily: PS_FONTS.body, fontSize: 12,
            color: theme.inkSoft,
          }}>{subtitle}</div>}
        </div>
      )}
    </div>
  );
}

// ── Tab bar ───────────────────────────────────────────────────
function PSTabBar({ active, onChange, theme, tabs }) {
  return (
    <div style={{
      padding: '8px 10px 18px',
      background: 'transparent',
    }}>
      <div style={{
        display: 'flex',
        background: theme.chrome,
        borderRadius: 18,
        padding: 5,
        boxShadow: theme.shadow,
        border: `0.5px solid ${theme.line}`,
      }}>
        {tabs.map(t => {
          const isActive = active === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              style={{
                flex: 1, appearance: 'none', border: 'none',
                background: isActive ? theme.card : 'transparent',
                color: isActive ? theme.ink : theme.inkSoft,
                padding: '8px 4px',
                borderRadius: 13,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
                fontFamily: PS_FONTS.body, fontSize: 10, fontWeight: 600,
                letterSpacing: 0.2,
                boxShadow: isActive
                  ? `0 1px 0 rgba(255,255,255,0.5) inset, 0 1px 2px rgba(0,0,0,0.10)`
                  : 'none',
                cursor: 'pointer',
                transition: 'all 0.18s ease',
              }}
            >
              <div style={{ width: 22, height: 22, color: isActive ? theme.accent : theme.inkSoft }}>
                {t.icon}
              </div>
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Icon set (custom line icons, warm) ────────────────────────
const PS_ICONS = {
  log: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M7 4h7l3 3v13H7z"/>
      <path d="M9 9h6M9 12h6M9 15h4"/>
    </svg>
  ),
  history: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <circle cx="12" cy="12" r="8"/>
      <path d="M12 8v4l3 2"/>
    </svg>
  ),
  beans: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <ellipse cx="12" cy="12" rx="8" ry="5.5" transform="rotate(-22 12 12)"/>
      <path d="M6.5 14.5C 9 12 12 12 17.5 9.5" />
    </svg>
  ),
  hardware: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <rect x="5" y="4" width="14" height="13" rx="2"/>
      <path d="M9 8h6M9 12h6M8 17v3M16 17v3"/>
    </svg>
  ),
  more: (
    <svg viewBox="0 0 24 24" fill="currentColor" width="100%" height="100%">
      <circle cx="6" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="18" cy="12" r="1.6"/>
    </svg>
  ),
  back: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M14 6l-6 6 6 6"/>
    </svg>
  ),
  plus: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" width="100%" height="100%">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  camera: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <rect x="3" y="7" width="18" height="13" rx="2"/>
      <circle cx="12" cy="13.5" r="3.5"/>
      <path d="M8 7l1.5-2h5L16 7"/>
    </svg>
  ),
  filter: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M4 5h16M7 12h10M10 19h4"/>
    </svg>
  ),
  sort: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M7 4v16M7 4l-3 3M7 4l3 3M17 20V4M17 20l-3-3M17 20l3-3"/>
    </svg>
  ),
  close: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" width="100%" height="100%">
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  ),
  check: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M5 12.5l4.5 4.5L19 7"/>
    </svg>
  ),
  chevron: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="100%" height="100%">
      <path d="M9 6l6 6-6 6"/>
    </svg>
  ),
};

// ── Glyph button (round, used in nav bar)
function PSIconBtn({ icon, theme, onClick, label, size = 32 }) {
  return (
    <button onClick={onClick} aria-label={label} style={{
      appearance: 'none', border: 'none',
      width: size, height: size, borderRadius: size / 2,
      background: theme.surface,
      border1: `0.5px solid ${theme.line}`,
      boxShadow: `inset 0 0 0 0.5px ${theme.line}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: theme.ink, cursor: 'pointer',
    }}>
      <div style={{ width: size * 0.55, height: size * 0.55 }}>{icon}</div>
    </button>
  );
}

// ── Modal sheet (bottom)
function PSSheet({ open, onClose, theme, children, title }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 50,
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
      background: 'rgba(0,0,0,0.35)',
      animation: 'ps-fade 0.2s ease',
    }}
    onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: theme.surface,
        borderTopLeftRadius: 20, borderTopRightRadius: 20,
        padding: '10px 0 22px',
        boxShadow: '0 -4px 30px rgba(0,0,0,0.3)',
        maxHeight: '85%', overflow: 'auto',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 8px' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: theme.lineStrong }} />
        </div>
        {title && (
          <div style={{ padding: '4px 18px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <PSDisplay size={20} theme={theme}>{title}</PSDisplay>
            <button onClick={onClose} style={{
              appearance: 'none', border: 'none', background: 'transparent', color: theme.inkSoft,
              fontFamily: PS_FONTS.body, fontSize: 14, cursor: 'pointer',
            }}>Close</button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

// ── Image lookups (Unsplash for beans/hardware) ───────────────
// Using deterministic Unsplash featured collection URLs.
const PS_PHOTOS = {
  // beans: bag photos
  b1: 'https://images.unsplash.com/photo-1559525323-cbb5269e4497?w=400&q=70&auto=format&fit=crop',
  b2: 'https://images.unsplash.com/photo-1611854779393-1b2da9d400fe?w=400&q=70&auto=format&fit=crop',
  b3: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&q=70&auto=format&fit=crop',
  // hardware
  m1: 'https://images.unsplash.com/photo-1572286258217-215cf8e08eaf?w=400&q=70&auto=format&fit=crop',
  m2: 'https://images.unsplash.com/photo-1610889556528-9a770e32642f?w=400&q=70&auto=format&fit=crop',
  g1: 'https://images.unsplash.com/photo-1606293459209-0b9576dfe40d?w=400&q=70&auto=format&fit=crop',
  g2: 'https://images.unsplash.com/photo-1517663154410-eb70b056e08b?w=400&q=70&auto=format&fit=crop',
};

Object.assign(window, {
  PSPlaceholder, PSPhoto, PSCard, PSSectionLabel, PSDisplay,
  PSPill, PSStars, PSField, PSInput, PSRoastBadge,
  PSNavBar, PSTabBar, PSIconBtn, PSSheet,
  PS_ICONS, PS_PHOTOS,
});
